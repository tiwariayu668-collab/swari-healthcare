import { GoogleGenAI, Type } from "@google/genai";
import { AnalysisResult } from "../types";

/**
 * Analyzes symptoms using the Gemini 3 Pro model to provide medical insights.
 * Uses gemini-3-pro-preview because symptom analysis involves complex reasoning and guidance.
 */
export const analyzeSymptoms = async (symptoms: string, age?: number): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const ageContext = age ? `The user is ${age} years old.` : "User age not specified.";
  const prompt = `Analyze the following symptoms and provide structured medical guidance. 
  ${ageContext}
  SYMPTOMS: "${symptoms}"
  
  Provide a professional, calm, and informative response including:
  1. A brief summary of the likely condition based on the age and symptoms.
  2. Recommended Over-The-Counter (OTC) medications with dosage and precautions appropriate for the user's age.
  3. Actionable home remedies and lifestyle adjustments (hydration, rest, humidity, etc.).
  4. An urgency level (Low, Medium, High).
  
  IMPORTANT: Always include a disclaimer that this is not a substitute for professional medical advice.`;

  const response = await ai.models.generateContent({
    model: "gemini-3-pro-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING },
          medications: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                type: { type: Type.STRING },
                dosage: { type: Type.STRING },
                precautions: { type: Type.STRING }
              },
              required: ["name", "type", "dosage", "precautions"]
            }
          },
          remedies: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                description: { type: Type.STRING },
                category: { type: Type.STRING }
              },
              required: ["title", "description", "category"]
            }
          },
          urgency: { type: Type.STRING, enum: ["Low", "Medium", "High"] }
        },
        required: ["summary", "medications", "remedies", "urgency"]
      }
    }
  });

  // Directly access text property as per @google/genai guidelines
  const text = response.text;
  if (!text) {
    throw new Error("No analysis response generated from the model.");
  }

  return JSON.parse(text.trim()) as AnalysisResult;
};