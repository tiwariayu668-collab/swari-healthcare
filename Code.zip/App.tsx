import React, { useState, useEffect, useRef } from 'react';
import { BodyRegion, AnalysisResult, Page, UserProfile } from './types';
import { analyzeSymptoms } from './services/geminiService';
import { Icons } from './components/Icons';
import { BodyMap } from './components/BodyMap';
import { ReliefDashboard } from './components/ReliefDashboard';
import { AnalysisSkeleton } from './components/Skeleton';
import { ShopPage } from './components/ShopPage';
import { AboutPage } from './components/AboutPage';
import { LoginPage } from './components/LoginPage';
import { ContactPage } from './components/ContactPage';
import { UserProfilePage } from './components/UserProfilePage';
import { ReviewsPage } from './components/ReviewsPage';
import { SwariChat } from './components/SwariChat';
import { SYMPTOM_CATEGORIES, MOCK_USER_PROFILE } from './constants';

const RECENT_SEARCHES_KEY = 'swari_recent_searches';

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [nightMode, setNightMode] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>(MOCK_USER_PROFILE);
  const [symptoms, setSymptoms] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<BodyRegion | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  
  const [recentSearches, setRecentSearches] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const searchContainerRef = useRef<HTMLDivElement>(null);

  // Global Scroll Reveal & Parallax
  useEffect(() => {
    if (!isLoggedIn) return;

    const handleScroll = () => {
      document.documentElement.style.setProperty('--scroll-y', `${window.scrollY}`);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });

    const observerOptions = {
      threshold: 0.05,
      rootMargin: "0px 0px -50px 0px"
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('revealed');
        }
      });
    }, observerOptions);

    const elements = document.querySelectorAll('.scroll-reveal, .scroll-reveal-left');
    elements.forEach(el => observer.observe(el));

    handleScroll();

    return () => {
      window.removeEventListener('scroll', handleScroll);
      elements.forEach(el => observer.unobserve(el));
    };
  }, [isLoggedIn, currentPage, analysis, isAnalyzing]);

  useEffect(() => {
    const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (saved) {
      try {
        setRecentSearches(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse search history", e);
      }
    }
  }, []);

  const handleRegionSelect = (region: BodyRegion) => {
    setSelectedRegion(region);
    if (!region) {
      setSymptoms('');
      return;
    }
    const query = `I'm feeling discomfort in my ${region.toLowerCase()}`;
    setSymptoms(query);
    if (window.innerWidth < 1024) {
      searchContainerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const saveSearchHistory = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    
    setRecentSearches(prev => {
      const updated = [trimmed, ...prev.filter(s => s.toLowerCase() !== trimmed.toLowerCase())].slice(0, 5);
      localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const handleSubmit = async (e?: React.FormEvent, customQuery?: string) => {
    if (e) e.preventDefault();
    const queryToAnalyze = customQuery || symptoms;
    if (!queryToAnalyze.trim()) return;

    setShowSuggestions(false);
    setIsInputFocused(false);
    setIsAnalyzing(true);
    setError(null);
    try {
      const result = await analyzeSymptoms(queryToAnalyze, userProfile.age);
      setAnalysis(result);
      saveSearchHistory(queryToAnalyze);
    } catch (err) {
      console.error(err);
      setError("Our systems couldn't process this analysis.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleReset = () => {
    setAnalysis(null);
    setSymptoms('');
    setSelectedRegion(null);
    setCurrentPage('home');
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateTo = (page: Page) => {
    setCurrentPage(page);
    setAnalysis(null);
    setIsMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isLoggedIn) return <LoginPage onLogin={() => setIsLoggedIn(true)} />;

  const renderContent = () => {
    if (isAnalyzing) {
      return (
        <div className="pt-20 px-6 animate-entrance">
          <AnalysisSkeleton />
          <div className="text-center mt-16 space-y-6">
            <p className="text-slate-400 font-black uppercase tracking-[0.5em] text-[10px]">Harmonizing Clinical Insights</p>
            <div className="flex justify-center gap-3">
              <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-breathe"></div>
              <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-breathe" style={{ animationDelay: '0.4s' }}></div>
              <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-breathe" style={{ animationDelay: '0.8s' }}></div>
            </div>
          </div>
        </div>
      );
    }

    if (analysis) {
      return (
        <div className="animate-entrance px-2 md:px-0">
          <ReliefDashboard 
            analysis={analysis} 
            onReset={handleReset} 
            onNavigateToContact={() => navigateTo('contact')} 
            nightMode={nightMode} 
          />
        </div>
      );
    }

    switch(currentPage) {
      case 'shop': return <ShopPage />;
      case 'about': return <AboutPage />;
      case 'contact': return <ContactPage nightMode={nightMode} />;
      case 'profile': return <UserProfilePage profile={userProfile} nightMode={nightMode} onUpdateProfile={(p) => setUserProfile({...userProfile, ...p})} />;
      case 'reviews': return <ReviewsPage nightMode={nightMode} />;
      default: return (
        <div className="max-w-7xl mx-auto px-6 py-6 md:py-12 lg:py-24 relative">
          {/* Stress-reducing Dynamic Ambiance Blobs */}
          <div className="absolute top-[10%] left-[-10%] w-[60rem] h-[60rem] bg-amber-200/10 dark:bg-amber-500/5 rounded-full blur-[160px] pointer-events-none animate-morph opacity-40"></div>
          <div className="absolute bottom-[-10%] right-[-10%] w-[50rem] h-[50rem] bg-teal-500/5 dark:bg-teal-500/3 rounded-full blur-[140px] pointer-events-none animate-morph opacity-30" style={{ animationDelay: '-4s' }}></div>
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[40rem] h-[40rem] bg-amber-100/10 dark:bg-amber-900/5 rounded-full blur-[180px] pointer-events-none animate-breathe opacity-20"></div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-24 items-start relative z-10">
            {/* Hero Section */}
            <div className="lg:col-span-7 space-y-12 lg:space-y-20 lg:sticky lg:top-40">
              <div className="space-y-8 scroll-reveal-left">
                <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-teal-500/10 border border-teal-500/20 backdrop-blur-md">
                  <div className="w-2 h-2 rounded-full bg-teal-500 animate-ping"></div>
                  <span className="text-[10px] font-black uppercase tracking-[0.3em] text-teal-600">AI Care Live</span>
                </div>
                <h1 className={`text-6xl md:text-7xl lg:text-9xl font-serif leading-[0.85] tracking-tight parallax-slide-right ${nightMode ? 'text-white' : 'text-slate-800'}`}>
                  Recovery at <br /> <span className="clip-text italic">your pace.</span>
                </h1>
                <p className={`text-xl md:text-2xl max-w-lg leading-relaxed ${nightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  An intelligent clinical sanctuary mapping your symptoms to a personalized path of relief.
                </p>
              </div>

              <div className="relative scroll-reveal stagger-1" ref={searchContainerRef}>
                <form onSubmit={handleSubmit} className="relative z-10 group">
                  <div className={`p-1.5 md:p-3 rounded-[2.5rem] md:rounded-[4rem] shadow-4xl transition-all duration-1000 border-2 ${
                    isInputFocused ? 'border-teal-500/50 bg-white scale-[1.02] dark:bg-slate-800 shadow-teal-500/20' : 'border-transparent bg-white/60 dark:bg-slate-800/60 backdrop-blur-3xl shadow-sm'
                  }`}>
                    <div className="flex items-center gap-4 px-6 py-5 md:py-7">
                      <Icons.Search className={`text-teal-500 transition-all duration-700 ${isInputFocused ? 'scale-125 rotate-90' : ''}`} size={26} />
                      <input 
                        type="text"
                        placeholder="Describe your symptoms..."
                        value={symptoms}
                        onFocus={() => { setShowSuggestions(true); setIsInputFocused(true); }}
                        onChange={(e) => setSymptoms(e.target.value)}
                        className={`flex-1 bg-transparent outline-none text-xl md:text-3xl font-medium tracking-tight ${nightMode ? 'text-white placeholder-slate-600' : 'text-slate-800 placeholder-slate-300'}`}
                      />
                      <button 
                        type="submit"
                        disabled={!symptoms.trim()}
                        className={`group/btn h-14 w-14 md:h-20 md:w-20 flex items-center justify-center rounded-[1.8rem] md:rounded-[2.5rem] transition-all duration-700 active:scale-90 ${
                          symptoms.trim() ? 'bg-teal-500 text-white shadow-2xl shadow-teal-500/40 animate-glow-pulse' : 'bg-slate-200 dark:bg-slate-700 text-slate-400'
                        }`}
                      >
                        <Icons.ChevronRight size={32} className="group-hover/btn:translate-x-2 transition-transform" />
                      </button>
                    </div>
                  </div>
                </form>
              </div>

              {/* Explore Categories */}
              <div className="space-y-12 scroll-reveal stagger-2">
                <div className="flex items-center gap-6">
                  <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 whitespace-nowrap">Rapid Diagnostics</span>
                  <div className="h-px bg-slate-200 dark:bg-slate-700 w-full"></div>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
                  {SYMPTOM_CATEGORIES.slice(0, 8).map((cat) => (
                    <button
                      key={cat.title}
                      onClick={() => { setSymptoms(cat.query); handleSubmit(undefined, cat.query); }}
                      className={`group p-6 md:p-8 rounded-[2.5rem] transition-all duration-700 text-left relative active:scale-95 border border-transparent hover:border-teal-500/30 shadow-sm hover:shadow-2xl ${
                        nightMode ? 'bg-slate-800/80' : 'bg-white/80 backdrop-blur-md'
                      }`}
                    >
                      <div className={`w-12 h-12 md:w-16 md:h-16 ${cat.color} rounded-2xl md:rounded-[1.8rem] flex items-center justify-center text-2xl md:text-4xl mb-6 transform transition-all duration-700 group-hover:scale-125 group-hover:rotate-12 group-hover:shadow-xl`}>
                        {cat.emoji}
                      </div>
                      <h3 className={`font-black text-[12px] md:text-[14px] leading-tight ${nightMode ? 'text-white' : 'text-slate-800'}`}>{cat.title}</h3>
                      <Icons.ChevronRight size={14} className="absolute bottom-8 right-8 text-teal-500 opacity-0 group-hover:opacity-100 group-hover:translate-x-2 transition-all" />
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Anatomical Side */}
            <div className="lg:col-span-5 flex flex-col items-center scroll-reveal stagger-3 pb-20">
              <div className="text-center mb-12 relative">
                <div className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-teal-500/10 border border-teal-500/20 mb-4">
                  <Icons.Activity size={14} className="text-teal-500 animate-pulse" />
                  <span className="text-[11px] font-black uppercase tracking-[0.4em] text-teal-600">Local Mapping</span>
                </div>
                <p className={`text-sm font-semibold opacity-40 uppercase tracking-[0.2em] ${nightMode ? 'text-white' : 'text-slate-800'}`}>Interactive Anatomical Insights</p>
              </div>
              <div className="w-full relative">
                <div className="absolute -inset-20 bg-teal-500/5 blur-[120px] rounded-full animate-morph"></div>
                <BodyMap onSelectRegion={handleRegionSelect} selectedRegion={selectedRegion} nightMode={nightMode} />
              </div>
            </div>
          </div>
        </div>
      );
    }
  };

  return (
    <div className={`min-h-screen transition-all duration-1000 pb-20 md:pb-0 selection:bg-teal-500/30 relative ${nightMode ? 'bg-slate-950' : 'bg-[#f4f7f8]'}`}>
      <div className="bg-ambiance"></div>
      <div className="bg-noise"></div>
      
      <nav className="fixed top-0 left-0 right-0 z-[60] glass border-b border-slate-100/50 dark:border-slate-800/50 px-4 md:px-8 lg:px-12 py-4 md:py-6 flex justify-between items-center transition-all duration-1000">
        <div className="flex items-center gap-2 md:gap-4 cursor-pointer group" onClick={handleReset}>
          <div className="w-10 h-10 md:w-14 md:h-14 rounded-2xl md:rounded-[1.8rem] bg-teal-500 flex items-center justify-center shadow-2xl shadow-teal-500/40 transform transition-all duration-700 group-hover:rotate-12 group-hover:scale-110">
            <Icons.HeartPulse className="text-white w-6 h-6 md:w-8 md:h-8" />
          </div>
          <div className="flex flex-col -space-y-0.5 md:-space-y-1">
            <span className={`font-black text-xl md:text-3xl tracking-tighter leading-none ${nightMode ? 'text-white' : 'text-slate-800'}`}>Swari</span>
            <span className="text-[8px] md:text-[10px] font-black uppercase tracking-[0.4em] text-teal-500">Sanctuary</span>
          </div>
        </div>

        <div className="hidden lg:flex items-center gap-14">
          {(['home', 'shop', 'about', 'reviews', 'contact'] as Page[]).map((p) => (
            <button
              key={p}
              onClick={() => navigateTo(p)}
              className={`relative py-1 text-[11px] font-black uppercase tracking-[0.4em] transition-all group ${
                currentPage === p ? 'text-teal-600' : (nightMode ? 'text-slate-400 hover:text-white' : 'text-slate-400 hover:text-teal-600')
              }`}
            >
              {p}
              <span className={`absolute bottom-0 left-0 w-full h-0.5 bg-teal-500 transition-transform duration-700 origin-left ${currentPage === p ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'}`}></span>
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={() => navigateTo('profile')}
            className={`flex items-center gap-2 md:gap-4 px-3 md:px-5 py-2 md:py-3 rounded-2xl md:rounded-[2rem] transition-all group liquid-button active:animate-bounce-micro ${
              currentPage === 'profile' ? 'bg-teal-600 text-white shadow-2xl shadow-teal-500/30' : 'bg-slate-100 dark:bg-slate-800 hover:bg-white dark:hover:bg-slate-700'
            }`}
          >
            <div className="w-6 h-6 md:w-8 md:h-8 rounded-full overflow-hidden border border-white/20">
              <img src={userProfile.avatar} className="w-full h-full object-cover" />
            </div>
            <span className="hidden md:inline text-[9px] md:text-[10px] font-black uppercase tracking-widest">Profile</span>
          </button>
          <button 
            onClick={() => setNightMode(!nightMode)}
            className={`p-2.5 md:p-4 rounded-xl md:rounded-[1.5rem] transition-all duration-700 hover:scale-110 active:rotate-[20deg] ${nightMode ? 'bg-slate-800 text-yellow-400 shadow-xl' : 'bg-slate-100 text-slate-500'}`}
          >
            {nightMode ? <Icons.Sun size={18} /> : <Icons.Moon size={18} />}
          </button>
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-500"
          >
            {isMobileMenuOpen ? <Icons.X size={20} /> : <Icons.Menu size={20} />}
          </button>
        </div>
      </nav>

      <main className="pt-24 md:pt-32 pb-12 md:pb-24 overflow-x-hidden min-h-screen relative z-10">
        {renderContent()}
      </main>

      <SwariChat nightMode={nightMode} />

      <footer className="py-20 md:py-32 border-t border-slate-100 dark:border-slate-800 text-center px-6 transition-all relative z-10">
        <div className="overflow-hidden mb-12">
          <p className="text-[10px] md:text-[12px] uppercase tracking-[0.8em] font-black text-slate-400 parallax-slide-left whitespace-nowrap">
            Clinical Compassion • High-Fidelity Diagnostics • Serene Care • Swari Sanctuary • Medical Excellence
          </p>
        </div>
        <p className="max-w-3xl mx-auto text-xl md:text-2xl leading-relaxed text-slate-400 italic font-medium scroll-reveal">
          "Your health is an intricate narrative. We are here to help you find the path back to balance."
        </p>
      </footer>
    </div>
  );
};

export default App;