export enum BodyRegion {
  HEAD = 'Head',
  CHEST = 'Chest',
  ABDOMEN = 'Abdomen',
  ARMS = 'Arms',
  LEGS = 'Legs',
  BACK = 'Back',
  NECK = 'Neck',
  JOINTS = 'Joints'
}

export type ViewMode = 'front' | 'back';
export type Gender = 'male' | 'female';

export type Page = 'home' | 'shop' | 'about' | 'login' | 'contact' | 'profile' | 'reviews';

export interface Review {
  id: string;
  userName: string;
  rating: number;
  comment: string;
  isVerified: boolean;
  date: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  price: number;
  image: string;
  rating: number;
  reviewCount: number;
  category: string;
  reviews: Review[];
}

export interface Remedy {
  title: string;
  description: string;
  category: 'Home' | 'Lifestyle' | 'Dietary';
}

export interface Medication {
  name: string;
  type: string;
  dosage: string;
  precautions: string;
}

export interface AnalysisResult {
  summary: string;
  medications: Medication[];
  remedies: Remedy[];
  urgency: 'Low' | 'Medium' | 'High';
}

export interface UserSearchHistory {
  id: string;
  query: string;
  date: string;
  resultSummary: string;
  urgency: 'Low' | 'Medium' | 'High';
}

export interface UserPurchase {
  id: string;
  productName: string;
  brand: string;
  date: string;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Cancelled';
  amount: number;
  image: string;
}

export interface UserProfile {
  name: string;
  email: string;
  age?: number;
  avatar?: string;
  history: UserSearchHistory[];
  savedRemedies: Remedy[];
  purchases: UserPurchase[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}