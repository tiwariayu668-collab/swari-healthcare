import { Product, BodyRegion, UserProfile, Review } from './types';

export const MOCK_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Advocil Max',
    brand: 'ReliefLabs',
    price: 1249.00,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviewCount: 1250,
    category: 'Pain Relief',
    reviews: [
      { id: 'r1', userName: 'Sarah J.', rating: 5, comment: 'Worked within 20 minutes for my migraine.', isVerified: true, date: '2023-10-15' }
    ]
  },
  {
    id: '2',
    name: 'SinusClear Spray',
    brand: 'NaturaHealth',
    price: 789.00,
    image: 'https://images.unsplash.com/photo-1550573105-4584e8d05267?auto=format&fit=crop&q=80&w=600',
    rating: 4.5,
    reviewCount: 840,
    category: 'Cold & Flu',
    reviews: [
      { id: 'r3', userName: 'Emma L.', rating: 5, comment: 'Finally a spray that doesn\'t burn.', isVerified: true, date: '2023-11-01' }
    ]
  },
  {
    id: '3',
    name: 'SleepWell Tea',
    brand: 'ZenLeaves',
    price: 995.00,
    image: 'https://images.unsplash.com/photo-1544787210-2827443cb69b?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviewCount: 2300,
    category: 'Wellness',
    reviews: [
      { id: 'r4', userName: 'John D.', rating: 5, comment: 'Great for when I can\'t sleep.', isVerified: true, date: '2023-11-05' }
    ]
  },
  {
    id: '4',
    name: 'PureTouch Sanitizer',
    brand: 'HygienePro',
    price: 499.00,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=600',
    rating: 4.7,
    reviewCount: 3100,
    category: 'Daily Care',
    reviews: [
      { id: 'r5', userName: 'Mike T.', rating: 5, comment: 'Doesn\'t dry out my hands. Smells great.', isVerified: true, date: '2023-12-10' }
    ]
  },
  {
    id: '5',
    name: 'QuickBand Flex',
    brand: 'HealStrip',
    price: 245.00,
    image: 'https://images.unsplash.com/photo-1603398938378-e54eab446f91?auto=format&fit=crop&q=80&w=600',
    rating: 4.6,
    reviewCount: 520,
    category: 'First Aid',
    reviews: [
      { id: 'r6', userName: 'Lucy K.', rating: 4, comment: 'Very flexible, stays on even when wet.', isVerified: true, date: '2024-01-05' }
    ]
  },
  {
    id: '6',
    name: 'N95 PureAir Mask',
    brand: 'BreatheSafe',
    price: 150.00,
    image: 'https://images.unsplash.com/photo-1584622781564-1d9876a13d00?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviewCount: 4500,
    category: 'Equipment',
    reviews: [
      { id: 'r7', userName: 'Mark R.', rating: 5, comment: 'Best fit I have found. Comfortable for long wear.', isVerified: true, date: '2024-02-12' }
    ]
  },
  {
    id: '7',
    name: 'DigestoGlow Tablets',
    brand: 'ReliefLabs',
    price: 650.00,
    image: 'https://images.unsplash.com/photo-1471864190281-ad5f9f8162e6?auto=format&fit=crop&q=80&w=600',
    rating: 4.4,
    reviewCount: 980,
    category: 'Wellness',
    reviews: [
      { id: 'r8', userName: 'Anna P.', rating: 4, comment: 'Helps a lot with bloating after heavy meals.', isVerified: true, date: '2024-01-20' }
    ]
  },
  {
    id: '8',
    name: 'PulseScan Oximeter',
    brand: 'VitalCheck',
    price: 2499.00,
    image: 'https://images.unsplash.com/photo-1583947581924-860bda6a26df?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    reviewCount: 1100,
    category: 'Equipment',
    reviews: [
      { id: 'r9', userName: 'David W.', rating: 5, comment: 'Accurate and fast readings.', isVerified: true, date: '2024-02-28' }
    ]
  },
  {
    id: '9',
    name: 'Antisep Cream Gold',
    brand: 'HealStrip',
    price: 320.00,
    image: 'https://images.unsplash.com/photo-1555633514-abcee6ad93e1?auto=format&fit=crop&q=80&w=600',
    rating: 4.7,
    reviewCount: 750,
    category: 'First Aid',
    reviews: [
      { id: 'r10', userName: 'Elena G.', rating: 5, comment: 'Healed my scrape overnight. No stinging.', isVerified: true, date: '2024-03-02' }
    ]
  },
  {
    id: '10',
    name: 'ThermoSnap Digital',
    brand: 'VitalCheck',
    price: 1850.00,
    image: 'https://images.unsplash.com/photo-1584036561566-baf8f5f1b144?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    reviewCount: 3200,
    category: 'Equipment',
    reviews: [
      { id: 'r11', userName: 'Tom B.', rating: 5, comment: 'Instant readings, great for kids.', isVerified: true, date: '2024-03-10' }
    ]
  },
  {
    id: '11',
    name: 'GauzeMaster Rolls',
    brand: 'HealStrip',
    price: 180.00,
    image: 'https://images.unsplash.com/photo-1583947215259-38e31be8751f?auto=format&fit=crop&q=80&w=600',
    rating: 4.5,
    reviewCount: 340,
    category: 'First Aid',
    reviews: [
      { id: 'r12', userName: 'Chris M.', rating: 4, comment: 'Good quality cotton, very absorbent.', isVerified: true, date: '2024-03-15' }
    ]
  },
  {
    id: '12',
    name: 'CoughRelief Syrup',
    brand: 'NaturaHealth',
    price: 540.00,
    image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbbb88?auto=format&fit=crop&q=80&w=600',
    rating: 4.6,
    reviewCount: 1500,
    category: 'Cold & Flu',
    reviews: [
      { id: 'r13', userName: 'Sophie H.', rating: 5, comment: 'Natural honey taste and very effective.', isVerified: true, date: '2024-03-20' }
    ]
  }
];

export const GLOBAL_REVIEWS: Review[] = [
  { id: 'g1', userName: 'Alex Sterling', rating: 5, comment: 'The anatomical mapping is incredibly intuitive. I found relief for my neck pain in minutes.', isVerified: true, date: 'Dec 12, 2024' },
  { id: 'g2', userName: 'Maya Rodriguez', rating: 4, comment: 'Love the minimalist aesthetic. It actually helps reduce my stress levels when I am feeling sick.', isVerified: true, date: 'Dec 10, 2024' },
  { id: 'g3', userName: 'Liam Chen', rating: 5, comment: 'Reliable clinical insights. The OTC recommendations match what my doctor usually suggests.', isVerified: true, date: 'Nov 28, 2024' },
  { id: 'g4', userName: 'Sophia Williams', rating: 5, comment: 'A sanctuary for health. Finally an app that doesn\'t feel like it is screaming at me.', isVerified: true, date: 'Nov 15, 2024' }
];

export const MOCK_USER_PROFILE: UserProfile = {
  name: 'Alex Sterling',
  email: 'alex.sterling@swari.com',
  age: 28,
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200',
  history: [
    { id: 'h1', query: 'Migraine with light sensitivity', date: '2023-12-10', resultSummary: 'Likely chronic migraine episode triggered by environmental factors.', urgency: 'Medium' },
    { id: 'h2', query: 'Sinus congestion and dry cough', date: '2023-12-05', resultSummary: 'Common seasonal sinus inflammation.', urgency: 'Low' },
    { id: 'h3', query: 'Sharp pain in lower back', date: '2023-11-28', resultSummary: 'Potential muscular strain from posture or activity.', urgency: 'Low' }
  ],
  savedRemedies: [
    { title: 'Ginger-Lemon Infusion', description: 'Gently brew fresh ginger with a slice of lemon to soothe nausea and inflammation.', category: 'Dietary' },
    { title: 'Lavender Compress', description: 'Apply a cool lavender-scented compress to the forehead for migraine relief.', category: 'Home' }
  ],
  purchases: [
    { id: 'p1', productName: 'Advocil Max', brand: 'ReliefLabs', date: '2023-12-10', status: 'Delivered', amount: 1249.00, image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&q=80&w=200' }
  ]
};

// High-fidelity anatomical regions with associated medical conditions
export interface RegionCondition {
  name: string;
  risk: 'Low' | 'Moderate' | 'High';
  symptoms: string;
}

export interface BodyRegionData {
  id: BodyRegion;
  path: string;
  conditions: RegionCondition[];
}

export const BODY_MAP_REGIONS_FRONT: BodyRegionData[] = [
  { 
    id: BodyRegion.HEAD, 
    path: "M50,12 c-7,0 -12,5 -12,14 c0,9 5,16 12,16 s12,-7 12,-16 c0,-9 -5,-14 -12,-14",
    conditions: [
      { name: "Migraine", risk: "Moderate", symptoms: "Pulsing pain, light sensitivity" },
      { name: "Sinusitis", risk: "High", symptoms: "Facial pressure, congestion, headache" },
      { name: "Vertigo", risk: "Low", symptoms: "Dizziness, spinning sensation" },
      { name: "Viral Fever", risk: "Moderate", symptoms: "Fever, chills, body ache" }
    ]
  },
  { 
    id: BodyRegion.NECK, 
    path: "M43,44 l14,0 c1,3 1,8 0,11 l-14,0 c-1,-3 -1,-8 0,-11",
    conditions: [
      { name: "Cervical Strain", risk: "High", symptoms: "Stiffness, limited motion" },
      { name: "Pharyngitis", risk: "Moderate", symptoms: "Sore throat, difficult swallowing" },
      { name: "Thyroiditis", risk: "Low", symptoms: "Swelling, fatigue" }
    ]
  },
  { 
    id: BodyRegion.CHEST, 
    path: "M28,62 c6,-5 38,-5 44,0 c6,4 10,18 10,26 c0,8 -15,12 -32,12 s-32,-4 -32,-12 c0,-8 4,-22 10,-26",
    conditions: [
      { name: "Bronchitis", risk: "Moderate", symptoms: "Cough, mucus, shortness of breath" },
      { name: "Asthma", risk: "Moderate", symptoms: "Wheezing, chest tightness" },
      { name: "Acid Reflux", risk: "High", symptoms: "Heartburn, chest burn" }
    ]
  },
  { 
    id: BodyRegion.ABDOMEN, 
    path: "M32,100 c10,4 26,4 36,0 c5,12 5,35 -2,45 c-10,5 -24,5 -32,0 c-7,-10 -7,-33 -2,-45",
    conditions: [
      { name: "Gastritis", risk: "High", symptoms: "Burning ache, indigestion" },
      { name: "IBS", risk: "Moderate", symptoms: "Cramping, bloating, gas" },
      { name: "Food Poisoning", risk: "Moderate", symptoms: "Nausea, vomiting, pain" }
    ]
  },
  { 
    id: BodyRegion.ARMS, 
    path: "M26,65 l-14,50 c-1,6 3,12 8,10 l8,-40 z M74,65 l14,50 c1,6 -3,12 -8,10 l-8,-40 z",
    conditions: [
      { name: "Tendonitis", risk: "High", symptoms: "Joint pain, tenderness" },
      { name: "Carpal Tunnel", risk: "Moderate", symptoms: "Numbness, tingling" }
    ]
  },
  { 
    id: BodyRegion.LEGS, 
    path: "M33,152 l-6,88 c-1,4 5,7 9,4 l9,-88 z M67,152 l6,88 c1,4 -5,7 -9,4 l-9,-88 z",
    conditions: [
      { name: "Muscle Strain", risk: "High", symptoms: "Sharp localized pain" },
      { name: "Sciatica", risk: "Moderate", symptoms: "Shooting nerve pain" },
      { name: "Varicose Veins", risk: "Low", symptoms: "Heavy legs, visible veins" }
    ]
  },
  { 
    id: BodyRegion.JOINTS, 
    path: "M48,52 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0 M15,115 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0 M85,115 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0 M32,235 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0 M68,235 a3,3 0 1,0 6,0 a3,3 0 1,0 -6,0",
    conditions: [
      { name: "Arthritis", risk: "High", symptoms: "Stiffness, swelling, reduced range" },
      { name: "Gout", risk: "Low", symptoms: "Intense sudden pain, redness" }
    ]
  }
];

export const BODY_MAP_REGIONS_BACK: BodyRegionData[] = [
  { 
    id: BodyRegion.HEAD, 
    path: "M50,12 c-7,0 -12,5 -12,14 c0,9 5,16 12,16 s12,-7 12,-16 c0,-9 -5,-14 -12,-14",
    conditions: [
      { name: "Tension Headache", risk: "High", symptoms: "Tight band sensation" }
    ]
  },
  { 
    id: BodyRegion.BACK, 
    path: "M32,62 c10,-4 26,-4 36,0 c8,30 8,60 0,90 c-10,4 -26,4 -36,0 c-8,-30 -8,-60 0,-90",
    conditions: [
      { name: "Lower Back Pain", risk: "High", symptoms: "Ache, stiffness" },
      { name: "Herniated Disc", risk: "Moderate", symptoms: "Radiating pain, weakness" },
      { name: "Kidney Stones", risk: "Low", symptoms: "Sharp flank pain, nausea" }
    ]
  },
  { 
    id: BodyRegion.ARMS, 
    path: "M26,65 l-14,50 c-1,6 3,12 8,10 l8,-40 z M74,65 l14,50 c1,6 -3,12 -8,10 l-8,-40 z",
    conditions: [
      { name: "Muscle Knot", risk: "High", symptoms: "Lumpy, tender spot" }
    ]
  },
  { 
    id: BodyRegion.LEGS, 
    path: "M33,152 l-6,88 c-1,4 5,7 9,4 l9,-88 z M67,152 l6,88 c1,4 -5,7 -9,4 l-9,-88 z",
    conditions: [
      { name: "Hamstring Strain", risk: "Moderate", symptoms: "Sharp pull in thigh" }
    ]
  }
];

export const SYMPTOM_CATEGORIES = [
  { 
    title: 'Respiratory', 
    emoji: '🫁', 
    color: 'bg-blue-50', 
    query: 'difficulty breathing, persistent cough, chest congestion, wheezing', 
    theme: 'blue' 
  },
  { 
    title: 'Neurological', 
    emoji: '🧠', 
    color: 'bg-purple-50', 
    query: 'migraine, dizziness, severe headache, numbness, vertigo', 
    theme: 'purple' 
  },
  { 
    title: 'Digestive', 
    emoji: '🥙', 
    color: 'bg-green-50', 
    query: 'stomach ache, nausea, acid reflux, bloating, constipation', 
    theme: 'green' 
  },
  { 
    title: 'Muscular', 
    emoji: '💪', 
    color: 'bg-orange-50', 
    query: 'lower back pain, muscle soreness, joint stiffness, cramps', 
    theme: 'orange' 
  },
  { 
    title: 'Dermatology', 
    emoji: '🧴', 
    color: 'bg-rose-50', 
    query: 'skin rash, persistent itching, dry skin patches, sudden acne flare-up', 
    theme: 'rose' 
  },
  { 
    title: 'Cardiovascular', 
    emoji: '❤️', 
    color: 'bg-red-50', 
    query: 'heart palpitations, rapid pulse, lightheadedness, chest tightness', 
    theme: 'red' 
  },
  { 
    title: 'Mental Health', 
    emoji: '🧘', 
    color: 'bg-indigo-50', 
    query: 'excessive anxiety, high stress levels, persistent low mood, sleep loss from worry', 
    theme: 'indigo' 
  },
  { 
    title: 'ENT', 
    emoji: '👂', 
    color: 'bg-amber-50', 
    query: 'ear ache, scale throat, sinus pressure, temporary hearing loss', 
    theme: 'amber' 
  },
  { 
    title: 'Sleep Care', 
    emoji: '😴', 
    color: 'bg-slate-100', 
    query: 'insomnia, restless leg syndrome, sleep apnea symptoms, morning fatigue', 
    theme: 'slate' 
  },
  { 
    title: 'Pediatric', 
    emoji: '🧸', 
    color: 'bg-pink-50', 
    query: 'childhood fever, teething discomfort, baby colic, infant skin irritation', 
    theme: 'pink' 
  }
];