import React, { useState } from 'react';
import { UserProfile } from '../types';
import { Icons } from './Icons';

interface UserProfilePageProps {
  profile: UserProfile;
  nightMode: boolean;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
}

export const UserProfilePage: React.FC<UserProfilePageProps> = ({ profile, nightMode, onUpdateProfile }) => {
  const [activeTab, setActiveTab] = useState<'history' | 'remedies' | 'orders' | 'settings'>('history');
  const [editMode, setEditMode] = useState(false);
  const [tempProfile, setTempProfile] = useState({ name: profile.name, email: profile.email, age: profile.age });

  const handleSaveSettings = () => {
    onUpdateProfile(tempProfile);
    setEditMode(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12 md:py-20 animate-fade-in">
      <header className="mb-16 flex flex-col md:flex-row items-center gap-10">
        <div className="relative group">
          <div className="w-32 h-32 rounded-[2.5rem] overflow-hidden border-4 border-teal-500 shadow-2xl transition-transform duration-500 group-hover:scale-105">
            <img src={profile.avatar} alt={profile.name} className="w-full h-full object-cover" />
          </div>
          <button className="absolute -bottom-2 -right-2 bg-white dark:bg-gray-800 p-3 rounded-2xl shadow-xl text-teal-500 border border-teal-50">
            <Icons.Activity size={18} />
          </button>
        </div>
        
        <div className="text-center md:text-left space-y-2">
          <h1 className={`text-4xl md:text-5xl font-serif ${nightMode ? 'text-white' : 'text-[#2D3748]'}`}>{profile.name}</h1>
          <p className="text-gray-400 font-medium tracking-wide">{profile.email} • Age: {profile.age || 'Not set'}</p>
          <div className="flex flex-wrap justify-center md:justify-start gap-4 mt-4">
            <div className="px-4 py-2 rounded-2xl bg-teal-50 dark:bg-teal-900/20 text-teal-600 text-[10px] font-bold uppercase tracking-widest border border-teal-100/50">
              Verified Member
            </div>
            <div className={`px-4 py-2 rounded-2xl text-[10px] font-bold uppercase tracking-widest border ${nightMode ? 'bg-gray-800 border-gray-700 text-gray-400' : 'bg-gray-50 border-gray-100 text-gray-500'}`}>
              Joined Nov 2023
            </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-12">
        {/* Navigation Sidebar */}
        <nav className="space-y-3">
          {[
            { id: 'history', label: 'Analysis History', icon: <Icons.Activity size={18} /> },
            { id: 'remedies', label: 'Saved Remedies', icon: <Icons.HeartPulse size={18} /> },
            { id: 'orders', label: 'Order History', icon: <Icons.ShoppingBag size={18} /> },
            { id: 'settings', label: 'Profile Settings', icon: <Icons.ShieldCheck size={18} /> }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`w-full flex items-center gap-4 px-8 py-5 rounded-[2rem] transition-all duration-300 text-[11px] font-bold uppercase tracking-widest active:animate-bounce-micro ${
                activeTab === tab.id 
                ? 'bg-teal-600 text-white shadow-xl shadow-teal-200' 
                : (nightMode ? 'bg-gray-800 text-gray-400 hover:text-white' : 'bg-white text-gray-400 border border-gray-50 hover:border-teal-100 hover:text-teal-600')
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </nav>

        {/* Content Area */}
        <div className={`lg:col-span-3 p-8 md:p-12 rounded-[3.5rem] border shadow-sm transition-all duration-500 ${
          nightMode ? 'bg-[#1A202C] border-gray-700' : 'bg-white border-gray-50'
        }`}>
          {activeTab === 'history' && (
            <div className="space-y-8 animate-fade-in">
              <div className="flex items-center gap-4 mb-8">
                <Icons.Activity className="text-teal-500" size={24} />
                <h2 className="text-2xl font-serif">Symptom History</h2>
              </div>
              <div className="space-y-6">
                {profile.history.map((entry, idx) => (
                  <div key={idx} className={`p-8 rounded-[2.5rem] border group transition-all duration-500 hover:shadow-xl ${
                    nightMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-transparent hover:bg-white hover:border-teal-50'
                  }`}>
                    <div className="flex justify-between items-start gap-4 mb-4">
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-teal-500 mb-2">{entry.date}</p>
                        <h3 className="text-xl font-bold">{entry.query}</h3>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-[9px] font-bold uppercase tracking-widest border ${
                        entry.urgency === 'High' ? 'bg-red-50 text-red-600 border-red-100' : 
                        entry.urgency === 'Medium' ? 'bg-orange-50 text-orange-600 border-orange-100' : 
                        'bg-teal-50 text-teal-600 border-teal-100'
                      }`}>
                        {entry.urgency}
                      </span>
                    </div>
                    <p className={`text-sm leading-relaxed ${nightMode ? 'text-gray-400' : 'text-gray-500'}`}>{entry.resultSummary}</p>
                    <button className="mt-6 flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-teal-500 hover:underline">
                      View Full Analysis <Icons.ChevronRight size={14} />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'remedies' && (
            <div className="space-y-8 animate-fade-in">
              <div className="flex items-center gap-4 mb-8">
                <Icons.HeartPulse className="text-teal-500" size={24} />
                <h2 className="text-2xl font-serif">Saved Remedies</h2>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {profile.savedRemedies.map((rem, idx) => (
                  <div key={idx} className={`p-8 rounded-[2.5rem] border ${
                    nightMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-transparent hover:bg-white hover:shadow-xl transition-all duration-500'
                  }`}>
                    <span className="text-[9px] font-bold text-teal-500 uppercase tracking-widest mb-2 block">{rem.category}</span>
                    <h4 className="text-lg font-bold mb-3">{rem.title}</h4>
                    <p className={`text-sm leading-relaxed mb-6 ${nightMode ? 'text-gray-400' : 'text-gray-500'}`}>{rem.description}</p>
                    <button className="text-[10px] font-bold uppercase tracking-widest text-red-400 hover:text-red-500 transition-colors">
                      Remove from saved
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'orders' && (
            <div className="space-y-8 animate-fade-in">
              <div className="flex items-center gap-4 mb-8">
                <Icons.ShoppingBag className="text-teal-500" size={24} />
                <h2 className="text-2xl font-serif">Purchase History</h2>
              </div>
              <div className="space-y-6">
                {profile.purchases.map((purchase, idx) => (
                  <div key={idx} className={`flex flex-col md:flex-row items-center gap-8 p-6 rounded-[2.5rem] border ${
                    nightMode ? 'bg-gray-800/50 border-gray-700' : 'bg-gray-50 border-transparent'
                  }`}>
                    <div className="w-24 h-24 rounded-[1.5rem] overflow-hidden bg-white flex-shrink-0 shadow-sm">
                      <img src={purchase.image} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 text-center md:text-left">
                      <div className="flex flex-wrap justify-center md:justify-start items-center gap-3 mb-1">
                        <h4 className="text-lg font-bold">{purchase.productName}</h4>
                        <span className={`px-2 py-0.5 rounded-full text-[8px] font-bold uppercase tracking-widest border ${
                          purchase.status === 'Delivered' ? 'bg-green-50 text-green-600 border-green-100' : 'bg-teal-50 text-teal-600 border-teal-100'
                        }`}>
                          {purchase.status}
                        </span>
                      </div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-4">{purchase.brand}</p>
                      <div className="flex justify-center md:justify-start gap-8 text-[11px] font-medium text-gray-500">
                        <span>Date: <span className="text-gray-900 dark:text-gray-100">{purchase.date}</span></span>
                        <span>Amount: <span className="text-gray-900 dark:text-gray-100">₹{purchase.amount.toFixed(2)}</span></span>
                      </div>
                    </div>
                    <button className={`px-8 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest transition-all ${
                      nightMode ? 'bg-gray-700 text-white' : 'bg-white text-teal-600 shadow-sm border border-teal-50'
                    }`}>
                      Track Order
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="space-y-12 animate-fade-in">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <Icons.ShieldCheck className="text-teal-500" size={24} />
                  <h2 className="text-2xl font-serif">Profile Settings</h2>
                </div>
                {!editMode ? (
                  <button 
                    onClick={() => setEditMode(true)}
                    className="flex items-center gap-2 text-teal-500 font-bold uppercase tracking-widest text-[10px]"
                  >
                    Edit Profile
                  </button>
                ) : (
                  <div className="flex gap-4">
                    <button 
                      onClick={() => setEditMode(false)}
                      className="text-gray-400 font-bold uppercase tracking-widest text-[10px]"
                    >
                      Cancel
                    </button>
                    <button 
                      onClick={handleSaveSettings}
                      className="text-teal-500 font-bold uppercase tracking-widest text-[10px]"
                    >
                      Save Changes
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-4">Full Name</label>
                  <input 
                    type="text" 
                    disabled={!editMode}
                    value={tempProfile.name}
                    onChange={(e) => setTempProfile({...tempProfile, name: e.target.value})}
                    className={`w-full px-8 py-4 rounded-[1.5rem] border transition-all outline-none ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    } disabled:opacity-50`}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-4">Email Address</label>
                  <input 
                    type="email" 
                    disabled={!editMode}
                    value={tempProfile.email}
                    onChange={(e) => setTempProfile({...tempProfile, email: e.target.value})}
                    className={`w-full px-8 py-4 rounded-[1.5rem] border transition-all outline-none ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    } disabled:opacity-50`}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest ml-4">Age</label>
                  <input 
                    type="number" 
                    disabled={!editMode}
                    value={tempProfile.age || ''}
                    onChange={(e) => setTempProfile({...tempProfile, age: parseInt(e.target.value) || undefined})}
                    className={`w-full px-8 py-4 rounded-[1.5rem] border transition-all outline-none ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    } disabled:opacity-50`}
                  />
                </div>
              </div>

              <div className="space-y-8 pt-8 border-t border-gray-50 dark:border-gray-800">
                <h3 className="text-xl font-bold">Security</h3>
                <div className="flex items-center justify-between p-6 rounded-[2rem] bg-orange-50/30 dark:bg-orange-900/10 border border-orange-100/50">
                  <div>
                    <h4 className="font-bold text-orange-600">Password</h4>
                    <p className="text-xs text-orange-400">Last changed 4 months ago</p>
                  </div>
                  <button className="px-6 py-2 rounded-xl bg-orange-100 text-orange-600 text-[9px] font-bold uppercase tracking-widest">
                    Update Password
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};