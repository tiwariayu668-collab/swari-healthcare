
import React from 'react';
import { 
  Search, 
  Moon, 
  Sun, 
  ChevronRight, 
  ShoppingBag, 
  Star, 
  CheckCircle, 
  ShieldCheck, 
  Droplets, 
  Activity,
  AlertCircle,
  Home,
  Thermometer,
  HeartPulse,
  Menu,
  X,
  User,
  Info,
  MessageSquare
} from 'lucide-react';

export const Icons = {
  Search,
  Moon,
  Sun,
  ChevronRight,
  ShoppingBag,
  Star,
  CheckCircle,
  ShieldCheck,
  Droplets,
  Activity,
  AlertCircle,
  Home,
  Thermometer,
  HeartPulse,
  Menu,
  X,
  User,
  Info,
  MessageSquare
};
