
import React from 'react';
import { Icons } from './Icons';

export const ContactPage: React.FC<{ nightMode: boolean }> = ({ nightMode }) => {
  return (
    <div className="relative min-h-screen">
      {/* Background Wallpaper - Image 2 Concept */}
      <div className={`fixed inset-0 z-0 pointer-events-none opacity-[0.06] grayscale transition-opacity duration-1000 ${nightMode ? 'invert' : ''}`}
           style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1551076805-e1869033e561?auto=format&fit=crop&q=80&w=1200)', backgroundSize: 'cover', backgroundPosition: 'center' }}>
      </div>

      <div className="relative z-10 max-w-6xl mx-auto px-6 py-12 md:py-20 animate-fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Contact Info */}
          <div className="space-y-12">
            <div className="space-y-4">
              <h1 className={`text-5xl md:text-6xl font-serif leading-tight ${nightMode ? 'text-white' : 'text-[#2D3748]'}`}>
                We're here to <span className="text-teal-500 italic">listen.</span>
              </h1>
              <p className={`text-lg max-w-md ${nightMode ? 'text-gray-400' : 'text-gray-500'}`}>
                Whether you have questions about our analysis or need help with an order, our team of care specialists is ready.
              </p>
            </div>

            <div className="space-y-8">
              {[
                { icon: <Icons.Activity className="text-teal-500" />, label: "Support Email", value: "care@swarihealthcare.com" },
                { icon: <Icons.ShieldCheck className="text-teal-500" />, label: "Business Hours", value: "Mon - Fri, 9am - 6pm EST" },
                { icon: <Icons.Home className="text-teal-500" />, label: "Headquarters", value: "12 Wellness Way, Serene Valley, CA" }
              ].map((item, i) => (
                <div key={i} className="flex gap-6 items-start group">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 transition-all group-hover:scale-110 ${nightMode ? 'bg-gray-800' : 'bg-white shadow-xl'}`}>
                    {item.icon}
                  </div>
                  <div>
                    <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mb-1">{item.label}</p>
                    <p className={`text-lg font-medium ${nightMode ? 'text-gray-200' : 'text-gray-700'}`}>{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Contact Form */}
          <div className={`p-8 md:p-12 rounded-[3rem] shadow-3xl border transition-colors duration-500 backdrop-blur-xl ${nightMode ? 'bg-gray-800/80 border-gray-700' : 'bg-white/80 border-white'}`}>
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-4">Full Name</label>
                  <input 
                    type="text" 
                    placeholder="Jane Doe"
                    className={`w-full px-6 py-4 rounded-2xl outline-none border transition-all ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50/50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    }`}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-4">Email Address</label>
                  <input 
                    type="email" 
                    placeholder="jane@example.com"
                    className={`w-full px-6 py-4 rounded-2xl outline-none border transition-all ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50/50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    }`}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-4">Subject</label>
                <select className={`w-full px-6 py-4 rounded-2xl outline-none border transition-all appearance-none ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50/50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    }`}>
                  <option>General Inquiry</option>
                  <option>Order Support</option>
                  <option>Medical Partnership</option>
                  <option>Technical Issue</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-4">Message</label>
                <textarea 
                  rows={4}
                  placeholder="How can we help you today?"
                  className={`w-full px-6 py-4 rounded-2xl outline-none border transition-all resize-none ${
                      nightMode ? 'bg-gray-700 border-gray-600 focus:border-teal-500 text-white' : 'bg-gray-50/50 border-transparent focus:border-teal-500 focus:bg-white text-gray-700'
                    }`}
                ></textarea>
              </div>
              <button className="w-full py-5 bg-teal-600 text-white font-black uppercase tracking-widest rounded-2xl shadow-2xl shadow-teal-600/30 hover:bg-teal-700 transition-all active:scale-95 flex items-center justify-center gap-2">
                Send Message <Icons.ChevronRight size={18} />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
