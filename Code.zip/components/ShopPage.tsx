import React, { useState, useMemo } from 'react';
import { MOCK_PRODUCTS } from '../constants';
import { Icons } from './Icons';
import { Product } from '../types';

export const ShopPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBrand, setSelectedBrand] = useState('All');
  const [maxPrice, setMaxPrice] = useState(5000); // Default high limit
  const [isFading, setIsFading] = useState(false);
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  const categories = ['All', 'Pain Relief', 'Cold & Flu', 'Wellness', 'Daily Care', 'First Aid', 'Equipment'];
  
  // Extract unique brands from products
  const brands = useMemo(() => {
    const b = new Set(MOCK_PRODUCTS.map(p => p.brand));
    return ['All', ...Array.from(b)];
  }, []);

  const filteredProducts = useMemo(() => {
    return MOCK_PRODUCTS.filter(p => {
      const matchCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.brand.toLowerCase().includes(searchQuery.toLowerCase());
      const matchBrand = selectedBrand === 'All' || p.brand === selectedBrand;
      const matchPrice = p.price <= maxPrice;
      
      return matchCategory && matchSearch && matchBrand && matchPrice;
    });
  }, [activeCategory, searchQuery, selectedBrand, maxPrice]);

  const handleFilterChange = (updater: () => void) => {
    setIsFading(true);
    setTimeout(() => {
      updater();
      setIsFading(false);
    }, 300);
  };

  return (
    <div className="relative min-h-screen">
      {/* Background Wallpaper */}
      <div className="fixed inset-0 z-0 pointer-events-none opacity-[0.04] grayscale transition-opacity duration-1000"
           style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=1200)', backgroundSize: '60%', backgroundPosition: 'center', backgroundRepeat: 'no-repeat' }}>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12 md:py-20 animate-entrance">
        <div className="flex flex-col lg:flex-row items-start justify-between gap-16 mb-16">
          <div className="space-y-8 text-center lg:text-left">
            <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-teal-500/5 border border-teal-500/10">
              <Icons.ShieldCheck size={14} className="text-teal-600" />
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-teal-600">Quality Verified Pharmacy</span>
            </div>
            <h1 className="text-7xl md:text-9xl font-serif text-slate-800 leading-[0.8] tracking-tight">Pure <br /> <span className="text-teal-500 italic">Recovery.</span></h1>
            <p className="text-2xl text-slate-500 max-w-xl leading-relaxed font-medium">
              Meticulously sourced clinical essentials, filtered for your specific needs.
            </p>
          </div>

          <div className="w-full lg:max-w-xl space-y-6">
            {/* Search Bar */}
            <div className="relative group">
              <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
                <Icons.Search className="text-slate-300 group-focus-within:text-teal-500 transition-colors" size={20} />
              </div>
              <input 
                type="text" 
                placeholder="Search products or brands..."
                value={searchQuery}
                onChange={(e) => handleFilterChange(() => setSearchQuery(e.target.value))}
                className="w-full pl-16 pr-8 py-6 rounded-[2.5rem] bg-white/80 backdrop-blur-md border border-slate-100 focus:border-teal-500/50 outline-none shadow-sm focus:shadow-xl transition-all font-medium text-lg"
              />
            </div>

            {/* Category Pills */}
            <div className="flex flex-wrap gap-2">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => handleFilterChange(() => setActiveCategory(cat))}
                  className={`px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-[0.2em] transition-all border ${
                    activeCategory === cat 
                    ? 'bg-slate-900 text-white border-slate-900' 
                    : 'bg-white/80 text-slate-400 border-slate-100 hover:text-teal-600'
                  }`}
                >
                  {cat}
                </button>
              ))}
              <button 
                onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                className={`px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-[0.2em] transition-all border flex items-center gap-2 ${
                  showAdvancedFilters ? 'bg-teal-500 text-white border-teal-500' : 'bg-white/80 text-teal-600 border-teal-100'
                }`}
              >
                <Icons.Activity size={12} /> Filters
              </button>
            </div>
          </div>
        </div>

        {/* Advanced Filters Panel */}
        {showAdvancedFilters && (
          <div className="mb-16 p-10 bg-white/60 backdrop-blur-3xl rounded-[4rem] border border-white/40 shadow-2xl animate-entrance flex flex-wrap gap-12">
            <div className="space-y-4 flex-1 min-w-[200px]">
              <label className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 ml-4">Select Brand</label>
              <div className="flex flex-wrap gap-2">
                {brands.map(brand => (
                  <button
                    key={brand}
                    onClick={() => handleFilterChange(() => setSelectedBrand(brand))}
                    className={`px-6 py-3 rounded-2xl text-[10px] font-black transition-all border ${
                      selectedBrand === brand 
                      ? 'bg-teal-500 text-white border-teal-500' 
                      : 'bg-white/50 text-slate-500 border-slate-200 hover:border-teal-500'
                    }`}
                  >
                    {brand}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-6 flex-1 min-w-[200px]">
              <div className="flex justify-between items-center ml-4 pr-4">
                <label className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Max Price: ₹{maxPrice}</label>
                <span className="text-[10px] font-black text-teal-600">₹5000</span>
              </div>
              <input 
                type="range" 
                min="0" 
                max="5000" 
                step="50"
                value={maxPrice}
                onChange={(e) => handleFilterChange(() => setMaxPrice(parseInt(e.target.value)))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-teal-500"
              />
              <div className="flex justify-between text-[8px] font-black text-slate-400 uppercase tracking-widest px-1">
                <span>₹0</span>
                <span>₹2500</span>
                <span>₹5000</span>
              </div>
            </div>
          </div>
        )}

        {/* Results Info */}
        <div className="mb-8 px-6 flex items-center gap-4 opacity-40">
           <div className="h-px bg-slate-200 flex-1"></div>
           <span className="text-[10px] font-black uppercase tracking-[0.4em]">{filteredProducts.length} Results Found</span>
           <div className="h-px bg-slate-200 flex-1"></div>
        </div>

        {/* Transitioning Grid Container */}
        <div className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-12 transition-all duration-500 ease-in-out ${
          isFading ? 'opacity-0 scale-[0.98] blur-sm' : 'opacity-100 scale-100 blur-0'
        }`}>
          {filteredProducts.map((product, idx) => (
            <div 
              key={`${product.id}-${activeCategory}-${selectedBrand}-${maxPrice}`}
              style={{ animationDelay: isFading ? '0s' : `${idx * 0.08}s` }}
              className={!isFading ? "animate-product-scale-in" : ""}
            >
              <ProductCard product={product} />
            </div>
          ))}
        </div>

        {filteredProducts.length === 0 && !isFading && (
          <div className="text-center py-48 animate-entrance">
            <div className="w-24 h-24 bg-slate-50 rounded-[2.5rem] flex items-center justify-center mx-auto mb-10">
              <Icons.Activity className="text-slate-200 animate-breathe" size={48} />
            </div>
            <p className="text-slate-400 font-black uppercase tracking-[0.5em] text-xs">No matching sanctuary essentials...</p>
            <button 
              onClick={() => handleFilterChange(() => {
                setActiveCategory('All');
                setSearchQuery('');
                setSelectedBrand('All');
                setMaxPrice(5000);
              })}
              className="mt-8 text-teal-600 font-black text-[10px] uppercase tracking-widest border-b border-teal-600/30 hover:border-teal-600 transition-all"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  return (
    <div className="group relative h-full">
      <div className="bg-white/80 backdrop-blur-md p-10 rounded-[5rem] border border-slate-50 shadow-sm hover:shadow-3xl transition-all duration-700 hover:-translate-y-4 flex flex-col h-full stagger-children">
        <div className="aspect-[4/5] rounded-[3.5rem] overflow-hidden bg-slate-50 mb-12 relative border border-slate-100/50">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-[1.2]" 
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="absolute top-8 left-8">
             <div className="bg-white/95 backdrop-blur-xl px-5 py-2 rounded-full shadow-2xl text-[10px] font-black text-teal-600 uppercase tracking-widest">
               Authentic
             </div>
          </div>
        </div>
        
        <div className="space-y-8 flex-1 flex flex-col">
          <div className="flex justify-between items-start gap-6">
            <div className="flex-1">
              <h3 className="font-black text-slate-800 text-3xl leading-tight group-hover:text-teal-500 transition-colors duration-500">{product.name}</h3>
              <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] mt-3">{product.brand}</p>
            </div>
            <div className="text-right">
              <span className="text-teal-600 font-black text-3xl">₹{product.price.toFixed(0)}</span>
              <p className="text-[9px] font-black text-slate-300 uppercase mt-1">Free Care Ship</p>
            </div>
          </div>
          
          <div className="flex items-center gap-2 pt-6 border-t border-slate-50">
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <Icons.Star 
                  key={i} 
                  size={14} 
                  className={i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-slate-100"} 
                />
              ))}
            </div>
            <span className="text-[10px] font-black text-slate-300 ml-auto uppercase tracking-widest">{product.reviewCount} Care Feedback</span>
          </div>
          
          <button className="mt-auto w-full py-7 bg-teal-600 text-white font-black text-[13px] uppercase tracking-[0.3em] rounded-[2.5rem] transition-all duration-700 hover:shadow-2xl hover:shadow-teal-500/40 active:scale-95 group-hover:animate-pulse-glow">
            Add to Sanctuary
          </button>
        </div>
      </div>
    </div>
  );
};