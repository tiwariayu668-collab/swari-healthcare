
import React from 'react';
import { Icons } from './Icons';

export const AboutPage: React.FC = () => {
  return (
    <div className="relative min-h-screen">
      {/* Dynamic Background Wallpapers with Golden Overlay */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div 
          className="absolute top-0 right-0 w-full h-1/2 opacity-[0.05] grayscale mix-blend-multiply transition-opacity duration-1000"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=1200)', backgroundSize: 'cover', backgroundPosition: 'center' }}
        ></div>
        <div 
          className="absolute bottom-0 left-0 w-full h-1/2 opacity-[0.05] grayscale mix-blend-multiply transition-opacity duration-1000"
          style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=1200)', backgroundSize: 'cover', backgroundPosition: 'center' }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-br from-amber-50/20 via-transparent to-teal-50/20"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-20">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center mb-32">
          <div className="space-y-8 scroll-reveal-left">
            <span className="text-teal-600 text-[11px] font-bold uppercase tracking-[0.4em] block">Our Philosophy</span>
            <h1 className="text-7xl font-serif text-slate-800 leading-[0.9] tracking-tight parallax-slide-left">
              Design for the <span className="text-teal-500 italic">vulnerable.</span>
            </h1>
            <p className="text-xl text-slate-500 leading-relaxed max-w-xl">
              We believe that technology should bow to the human condition. When you are unwell, your screen should not be a source of noise—it should be a digital sanctuary.
            </p>
            <div className="flex gap-6 pt-4 stagger-children">
              <div className="flex -space-x-3">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="w-12 h-12 rounded-full border-2 border-white overflow-hidden shadow-lg">
                    <img src={`https://i.pravatar.cc/100?img=${i + 10}`} alt="avatar" />
                  </div>
                ))}
                <div className="w-12 h-12 rounded-full border-2 border-white bg-teal-500 flex items-center justify-center text-white text-xs font-bold shadow-lg">
                  +2k
                </div>
              </div>
              <div>
                <p className="font-bold text-slate-800">Trusted globally</p>
                <p className="text-xs text-slate-400">Validated by 2,400+ health professionals</p>
              </div>
            </div>
          </div>
          <div className="relative scroll-reveal">
            <div className="aspect-[4/5] rounded-[4rem] overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-1000 border-8 border-white">
              <img 
                src="https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=1200" 
                className="w-full h-full object-cover scale-110 hover:scale-100 transition-transform duration-1000"
                alt="Community Care"
              />
            </div>
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-amber-500/10 morph-blob -z-10 blur-3xl"></div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
          {[
            { icon: <Icons.Activity className="text-teal-500" />, title: "Precision", desc: "AI trained on millions of clinical markers to find the signal in the noise." },
            { icon: <Icons.HeartPulse className="text-teal-500" />, title: "Empathy", desc: "UI designed with accessibility and light sensitivity as core principles." },
            { icon: <Icons.ShieldCheck className="text-teal-500" />, title: "Privacy", desc: "Your symptoms stay between you and your care plan. Zero data-selling." }
          ].map((item, i) => (
            <div key={i} className={`group p-12 rounded-[3.5rem] bg-white/70 backdrop-blur-md border border-slate-50 shadow-sm hover:shadow-2xl transition-all duration-700 hover:-translate-y-4 scroll-reveal stagger-${i + 1}`}>
              <div className="w-16 h-16 rounded-[1.5rem] bg-teal-50 flex items-center justify-center mb-10 transition-transform group-hover:rotate-12">
                {item.icon}
              </div>
              <h3 className="text-2xl font-bold text-slate-800 mb-4">{item.title}</h3>
              <p className="text-slate-500 leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>
        
        <div className="rounded-[5rem] bg-slate-900 p-20 text-white relative overflow-hidden text-center scroll-reveal">
          <div className="absolute inset-0 opacity-20">
            <img src="https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&q=80&w=2000" className="w-full h-full object-cover" />
          </div>
          <div className="relative z-10 max-w-3xl mx-auto space-y-10">
            <h2 className="text-5xl font-serif leading-tight scroll-reveal stagger-1 parallax-slide-right">Join the movement toward peaceful health.</h2>
            <p className="text-slate-400 text-xl leading-relaxed scroll-reveal stagger-2">
              We're not just building an app; we're redefining the clinical experience. Secure, serene, and scientifically accurate.
            </p>
            <button className="px-12 py-5 bg-teal-500 hover:bg-teal-600 text-white font-bold rounded-full shadow-2xl shadow-teal-500/40 transition-all active:scale-95 scroll-reveal stagger-3">
              Become a Partner
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
