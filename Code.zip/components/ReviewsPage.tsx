
import React, { useState } from 'react';
import { Icons } from './Icons';
import { GLOBAL_REVIEWS } from '../constants';

export const ReviewsPage: React.FC<{ nightMode: boolean }> = ({ nightMode }) => {
  const [userRating, setUserRating] = useState(5);
  const [comment, setComment] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    setComment('');
    setTimeout(() => setShowSuccess(false), 3000);
  };

  return (
    <div className="relative min-h-screen">
      {/* Background Wallpaper - Image 3 Concept (Team hands) */}
      <div className={`fixed inset-0 z-0 pointer-events-none opacity-[0.05] grayscale transition-opacity duration-1000 ${nightMode ? 'invert' : ''}`}
           style={{ backgroundImage: 'url(https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&q=80&w=1200)', backgroundSize: 'cover', backgroundPosition: 'center' }}>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 py-12 md:py-20 animate-entrance">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
          
          {/* Left Column: Stats and Submission */}
          <div className="lg:col-span-5 space-y-16">
            <div className="space-y-8 stagger-children">
              <div className="inline-flex items-center gap-3 px-5 py-2 rounded-full bg-teal-500/5 border border-teal-500/10">
                <Icons.Star size={14} className="text-teal-600 fill-teal-600" />
                <span className="text-[10px] font-black uppercase tracking-[0.4em] text-teal-600">Verified Sanctuary Feedback</span>
              </div>
              <h1 className={`text-6xl md:text-8xl font-serif leading-[0.9] tracking-tight parallax-slide-right ${nightMode ? 'text-white' : 'text-slate-800'}`}>
                Voice of the <br /> <span className="text-teal-500 italic">Sanctuary.</span>
              </h1>
              <p className={`text-xl leading-relaxed font-medium ${nightMode ? 'text-slate-400' : 'text-slate-500'}`}>
                Sharing experiences helps our community find the most effective paths to recovery.
              </p>
            </div>

            <div className={`p-10 rounded-[4rem] border transition-all duration-700 ${
              nightMode ? 'bg-slate-800/80 border-slate-700' : 'bg-white/80 border-white shadow-3xl shadow-teal-500/5'
            }`}>
              <h2 className={`text-3xl font-serif mb-10 ${nightMode ? 'text-white' : 'text-slate-800'}`}>Write a Review</h2>
              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-4">Select Rating</label>
                  <div className="flex gap-4 ml-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setUserRating(star)}
                        className={`transition-all ${userRating >= star ? 'scale-125' : 'opacity-30 grayscale'}`}
                      >
                        <Icons.Star size={32} className={`${userRating >= star ? 'fill-yellow-400 text-yellow-400' : 'text-slate-300'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-4">Your Feedback</label>
                  <textarea
                    required
                    value={comment}
                    onChange={(e) => setComment(e.target.value)}
                    placeholder="Tell others about your recovery journey..."
                    className={`w-full p-8 rounded-[2.5rem] outline-none border transition-all resize-none min-h-[200px] ${
                      nightMode ? 'bg-slate-700 border-slate-600 text-white' : 'bg-slate-50/50 border-transparent focus:bg-white focus:border-teal-500 text-slate-700'
                    }`}
                  />
                </div>

                <button 
                  type="submit"
                  className="w-full py-6 rounded-[2rem] bg-teal-600 text-white font-black text-[12px] uppercase tracking-widest shadow-2xl hover:bg-teal-700 active:scale-95 transition-all animate-glow-pulse"
                >
                  Share Experience
                </button>

                {showSuccess && (
                  <div className="p-6 bg-teal-50 border border-teal-100 rounded-[2rem] text-teal-600 font-bold text-center animate-entrance">
                    Your voice has been added to the sanctuary.
                  </div>
                )}
              </form>
            </div>
          </div>

          {/* Right Column: Review List */}
          <div className="lg:col-span-7 space-y-10">
            <div className="flex items-center gap-6 mb-10">
              <span className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-400 whitespace-nowrap">Recent Reflections</span>
              <div className="h-px bg-slate-200 dark:bg-slate-700 w-full"></div>
            </div>

            <div className="space-y-8">
              {GLOBAL_REVIEWS.map((review, idx) => (
                <div key={review.id} className={`p-10 rounded-[4rem] border transition-all duration-700 hover:-translate-y-2 group animate-entrance stagger-${(idx % 5) + 1} ${
                  nightMode ? 'bg-slate-800/40 border-slate-700' : 'bg-white border-slate-50 shadow-sm hover:shadow-2xl'
                }`}>
                  <div className="flex justify-between items-start mb-8">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 rounded-full bg-teal-500/10 flex items-center justify-center text-teal-600 font-black">
                        {review.userName.charAt(0)}
                      </div>
                      <div>
                        <h4 className={`text-xl font-black ${nightMode ? 'text-white' : 'text-slate-800'}`}>{review.userName}</h4>
                        <div className="flex items-center gap-2 mt-1">
                          <Icons.ShieldCheck size={12} className="text-teal-500" />
                          <span className="text-[9px] font-bold uppercase tracking-widest text-teal-600">Verified Journey</span>
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{review.date}</span>
                  </div>

                  <div className="flex gap-1 mb-6">
                    {[...Array(5)].map((_, i) => (
                      <Icons.Star 
                        key={i} 
                        size={14} 
                        className={i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-slate-100"} 
                      />
                    ))}
                  </div>

                  <p className={`text-xl leading-relaxed font-medium italic ${nightMode ? 'text-slate-300' : 'text-slate-500'}`}>
                    "{review.comment}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
