
import React, { useState, useEffect } from 'react';
import { Icons } from './Icons';

interface LoginPageProps {
  onLogin: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  const handleSocialLogin = (platform: string) => {
    console.log(`Logging in with ${platform}`);
    onLogin();
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center px-4 md:px-6 overflow-hidden bg-[#FDFBF7] dark:bg-[#0F172A] transition-colors duration-1000">
      {/* Dynamic Background: Cinematic & Serene */}
      <div className="absolute inset-0 z-0">
        <div 
          className="absolute inset-0 opacity-[0.08] dark:opacity-[0.05] grayscale mix-blend-multiply transition-opacity duration-[2s]"
          style={{ 
            backgroundImage: 'url(https://images.unsplash.com/photo-1516549221187-fb9d4734d73a?auto=format&fit=crop&q=80&w=2000)', 
            backgroundSize: 'cover', 
            backgroundPosition: 'center' 
          }}
        ></div>
        
        {/* Animated Fluid Blobs */}
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-amber-200/30 dark:bg-amber-500/10 rounded-full blur-[120px] animate-morph opacity-60"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-teal-500/20 dark:bg-teal-500/10 rounded-full blur-[100px] animate-morph opacity-40" style={{ animationDelay: '-4s' }}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[80%] h-[80%] bg-white/40 dark:bg-slate-900/0 rounded-full blur-[140px] pointer-events-none"></div>
      </div>

      <div className={`max-w-md w-full p-8 md:p-12 bg-white/70 dark:bg-slate-900/80 backdrop-blur-[60px] rounded-[4rem] md:rounded-[5rem] shadow-[0_50px_100px_rgba(0,0,0,0.1)] border border-white/60 dark:border-slate-800/60 text-center transition-all duration-[1.5s] relative z-10 ${isLoaded ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
        
        {/* Brand Icon with Pulse */}
        <div className="relative inline-block mb-10 group">
          <div className="absolute inset-0 bg-teal-500/20 rounded-full blur-2xl group-hover:blur-3xl transition-all duration-500"></div>
          <div className="relative w-24 h-24 bg-teal-500 rounded-[2.5rem] flex items-center justify-center shadow-2xl shadow-teal-500/40 transform group-hover:rotate-12 group-hover:scale-110 transition-all duration-700">
            <Icons.HeartPulse className="text-white animate-pulse" size={40} />
          </div>
        </div>
        
        <div className="space-y-3 mb-12 animate-entrance" style={{ animationDelay: '0.2s' }}>
          <h1 className="text-4xl md:text-5xl font-serif text-slate-800 dark:text-white leading-tight tracking-tight">
            {isSignUp ? 'Create your ' : 'Welcome to '}
            <span className="text-teal-500 italic">{isSignUp ? 'Sanctuary.' : 'Swari.'}</span>
          </h1>
          <p className="text-slate-500 dark:text-slate-400 text-sm md:text-base font-medium opacity-80">
            {isSignUp ? 'Begin your journey to a more peaceful recovery.' : 'Return to your clinical sanctuary.'}
          </p>
        </div>

        {/* Social Logins - More Attractively Designed */}
        <div className="grid grid-cols-2 gap-5 mb-10 animate-entrance" style={{ animationDelay: '0.3s' }}>
          <button 
            onClick={() => handleSocialLogin('Google')}
            className="flex items-center justify-center gap-3 py-4 rounded-3xl bg-white/50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-800 hover:shadow-[0_20px_40px_rgba(0,0,0,0.05)] transition-all active:scale-95 group"
          >
            <svg className="w-5 h-5 group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-600 dark:text-slate-300">Google</span>
          </button>
          <button 
            onClick={() => handleSocialLogin('Meta')}
            className="flex items-center justify-center gap-3 py-4 rounded-3xl bg-blue-500/5 border border-blue-500/20 hover:bg-blue-500/10 hover:shadow-[0_20px_40px_rgba(59,130,246,0.1)] transition-all active:scale-95 group"
          >
            <svg className="w-6 h-6 text-[#1877F2] fill-current group-hover:scale-110 transition-transform" viewBox="0 0 24 24">
              <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
            </svg>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-[#1877F2]">Meta</span>
          </button>
        </div>

        <div className="relative mb-10 animate-entrance" style={{ animationDelay: '0.4s' }}>
          <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100 dark:border-slate-800"></div></div>
          <div className="relative flex justify-center text-[9px] uppercase tracking-[0.4em] font-black text-slate-400">
            <span className="px-6 bg-white/0 dark:bg-slate-900/0 backdrop-blur-3xl transition-colors">Or secure email</span>
          </div>
        </div>

        <form className="space-y-6 text-left" onSubmit={handleSubmit}>
          {isSignUp && (
            <div className="space-y-2 animate-entrance" style={{ animationDelay: '0.5s' }}>
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-5">Full Name</label>
              <input 
                type="text" 
                placeholder="Alex Sterling"
                required
                className="w-full px-8 py-5 rounded-3xl bg-slate-50/50 dark:bg-slate-800/30 border border-transparent focus:border-teal-500/40 focus:bg-white dark:focus:bg-slate-800 transition-all outline-none text-slate-700 dark:text-slate-200 shadow-inner"
              />
            </div>
          )}
          <div className="space-y-2 animate-entrance" style={{ animationDelay: '0.6s' }}>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-5">Email Address</label>
            <input 
              type="email" 
              placeholder="care@swari.com"
              required
              className="w-full px-8 py-5 rounded-3xl bg-slate-50/50 dark:bg-slate-800/30 border border-transparent focus:border-teal-500/40 focus:bg-white dark:focus:bg-slate-800 transition-all outline-none text-slate-700 dark:text-slate-200 shadow-inner"
            />
          </div>
          <div className="space-y-2 animate-entrance" style={{ animationDelay: '0.7s' }}>
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-5">Password</label>
            <input 
              type="password" 
              placeholder="••••••••"
              required
              className="w-full px-8 py-5 rounded-3xl bg-slate-50/50 dark:bg-slate-800/30 border border-transparent focus:border-teal-500/40 focus:bg-white dark:focus:bg-slate-800 transition-all outline-none text-slate-700 dark:text-slate-200 shadow-inner"
            />
          </div>
          
          <div className="pt-4 animate-entrance" style={{ animationDelay: '0.8s' }}>
            <button 
              type="submit"
              className="w-full py-6 bg-teal-600 text-white font-black text-[12px] uppercase tracking-[0.4em] rounded-[2rem] shadow-[0_20px_40px_rgba(20,184,166,0.3)] hover:bg-teal-700 hover:shadow-[0_25px_50px_rgba(20,184,166,0.4)] transition-all active:scale-[0.98] animate-glow-pulse"
            >
              {isSignUp ? 'Begin Sanctuary' : 'Enter Clinic'}
            </button>
          </div>
        </form>

        <div className="mt-12 pt-8 border-t border-slate-100 dark:border-slate-800 animate-entrance" style={{ animationDelay: '0.9s' }}>
          <p className="text-sm text-slate-400 font-medium">
            {isSignUp ? 'Already a resident?' : "New to Swari?"}{' '}
            <button 
              onClick={() => setIsSignUp(!isSignUp)}
              className="text-teal-600 font-black cursor-pointer hover:underline focus:outline-none ml-1 uppercase text-[10px] tracking-widest"
            >
              {isSignUp ? 'Login here' : 'Join the Sanctuary'}
            </button>
          </p>
        </div>
        
        {/* Trust Badges */}
        <div className="mt-8 flex justify-center items-center gap-6 opacity-40 grayscale animate-entrance" style={{ animationDelay: '1s' }}>
           <div className="flex items-center gap-2">
             <Icons.ShieldCheck size={14} />
             <span className="text-[8px] font-bold uppercase tracking-widest">Privacy First</span>
           </div>
           <div className="flex items-center gap-2">
             <Icons.Activity size={14} />
             <span className="text-[8px] font-bold uppercase tracking-widest">Verified Insights</span>
           </div>
        </div>
      </div>
    </div>
  );
};
