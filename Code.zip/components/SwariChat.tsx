
import React, { useState, useRef, useEffect } from 'react';
import { Icons } from './Icons';
import { GoogleGenAI } from "@google/genai";
import { ChatMessage } from '../types';

export const SwariChat: React.FC<{ nightMode: boolean }> = ({ nightMode }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "Peace be with you. I am Swari AI, your clinical guide. How can I assist your recovery today?",
      timestamp: Date.now(),
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  const [renderedMessageCount, setRenderedMessageCount] = useState(0);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
      setRenderedMessageCount(messages.length);
      // Prevent body scroll on mobile when chat is open
      if (window.innerWidth < 768) {
        document.body.style.overflow = 'hidden';
      }
    } else {
      document.body.style.overflow = '';
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || isTyping) return;

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.0-flash-exp',
        contents: [
          {
            role: 'user',
            parts: [{ text: `You are Swari AI, a compassionate clinical guide at Swari Sanctuary. Your tone is serene, professional, and empathetic. Always include a disclaimer if giving health advice. Here is the conversation so far: ${messages.map(m => `${m.role}: ${m.text}`).join('\n')}\nUser: ${input}` }]
          }
        ],
        config: {
          systemInstruction: "You are Swari AI. You guide users through their health concerns with calmness and clarity. You are part of a 'Calm-Tech' platform. Keep responses concise and comforting.",
        }
      });

      const aiText = response.text || "I apologize, my clinical sensors are recalibrating. Could you please repeat that?";
      
      const modelMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: aiText,
        timestamp: Date.now(),
      };

      setMessages(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error("Chat error:", error);
      const errorMessage: ChatMessage = {
        id: 'error',
        role: 'model',
        text: "The sanctuary signal is weak. Please try again in a moment.",
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className={`fixed z-[100] flex flex-col items-end transition-all duration-500 ${isOpen ? 'inset-0 md:inset-auto md:bottom-8 md:right-8' : 'bottom-6 right-6 md:bottom-8 md:right-8'}`}>
      
      {/* Mobile-Friendly Chat Window */}
      <div 
        className={`flex flex-col rounded-t-[3rem] md:rounded-[3.5rem] shadow-4xl border transition-all duration-700 origin-bottom-right glass overflow-hidden ${
          isOpen 
            ? 'w-full h-full md:w-[420px] md:h-[650px] opacity-100 scale-100 translate-y-0 pointer-events-auto' 
            : 'w-0 h-0 opacity-0 scale-95 translate-y-20 pointer-events-none'
        } ${nightMode ? 'dark:bg-slate-900/95 dark:border-slate-800' : 'bg-white/95 border-teal-50/50'}`}
      >
        {/* Header - Refined for Mobile */}
        <div className="p-6 md:p-8 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-white/20 dark:bg-slate-900/20 backdrop-blur-md">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 md:w-14 md:h-14 rounded-2xl bg-teal-500 flex items-center justify-center shadow-2xl shadow-teal-500/30 transform rotate-3">
              <Icons.Activity className="text-white" size={24} />
            </div>
            <div>
              <h3 className={`font-black text-lg md:text-xl tracking-tight ${nightMode ? 'text-white' : 'text-slate-800'}`}>Swari AI</h3>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-teal-500 animate-ping"></span>
                <p className="text-[10px] font-black text-teal-500 uppercase tracking-[0.2em]">Sanctuary Link Active</p>
              </div>
            </div>
          </div>
          <button 
            onClick={() => setIsOpen(false)}
            className="p-3 md:p-4 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-all active:scale-90"
          >
            <Icons.X size={20} className="text-slate-500" />
          </button>
        </div>

        {/* Messages - Optimized Scrollable Area */}
        <div className="flex-1 overflow-y-auto p-6 md:p-10 space-y-8 scrollbar-hide">
          {messages.map((msg, idx) => {
            const delay = isOpen ? `${Math.max(0, idx - (renderedMessageCount - 5)) * 0.1}s` : '0s';
            
            return (
              <div 
                key={msg.id} 
                className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div 
                  style={{ animationDelay: delay }}
                  className={`max-w-[88%] p-6 md:p-7 rounded-[2rem] text-[15px] md:text-base leading-relaxed animate-bubble shadow-sm ${
                    msg.role === 'user' 
                      ? (nightMode ? 'bg-teal-600 text-white rounded-tr-none' : 'bg-slate-900 text-white rounded-tr-none')
                      : (nightMode ? 'bg-slate-800/80 text-slate-200 rounded-tl-none border border-slate-700' : 'bg-teal-50 text-teal-900 rounded-tl-none border border-teal-100/50')
                  }`}
                >
                  {msg.text}
                </div>
                <div 
                   style={{ animationDelay: `${parseFloat(delay) + 0.1}s` }}
                   className="text-[9px] font-black text-slate-400 mt-2.5 px-3 uppercase tracking-widest animate-bubble opacity-60"
                >
                  {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            );
          })}
          {isTyping && (
            <div className="flex flex-col items-start">
              <div className={`p-6 rounded-[2rem] rounded-tl-none ${nightMode ? 'bg-slate-800 border border-slate-700' : 'bg-teal-50 border border-teal-100/50'} animate-breathe`}>
                <div className="flex gap-2">
                  <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
                  <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-1.5 h-1.5 bg-teal-500 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Input Area - Fixed Bottom for Mobile */}
        <form onSubmit={handleSendMessage} className="p-6 md:p-8 border-t border-slate-100 dark:border-slate-800 bg-white/50 dark:bg-slate-900/50 backdrop-blur-xl">
          <div className={`flex items-center gap-3 p-2.5 rounded-[2.2rem] border transition-all shadow-inner ${
            nightMode ? 'bg-slate-800/50 border-slate-700' : 'bg-white/50 border-slate-200'
          }`}>
            <input 
              type="text"
              placeholder="Speak with the sanctuary..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              className="flex-1 bg-transparent outline-none px-6 py-4 text-[15px] font-medium placeholder:text-slate-400"
            />
            <button 
              type="submit"
              disabled={!input.trim() || isTyping}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                input.trim() ? 'bg-teal-500 text-white shadow-xl shadow-teal-500/30' : 'bg-slate-100 dark:bg-slate-700 text-slate-400'
              }`}
            >
              <Icons.ChevronRight size={24} className={isTyping ? 'animate-spin' : 'group-hover:translate-x-1 transition-transform'} />
            </button>
          </div>
          <div className="flex items-center justify-center gap-4 mt-4 opacity-40">
             <div className="h-px bg-slate-200 dark:bg-slate-800 flex-1"></div>
             <p className="text-[8px] font-black uppercase tracking-[0.3em] whitespace-nowrap">Clinical Compassion Engine</p>
             <div className="h-px bg-slate-200 dark:bg-slate-800 flex-1"></div>
          </div>
        </form>
      </div>

      {/* Floating Toggle Button - Highly Visible FAB */}
      {!isOpen && (
        <button 
          onClick={() => setIsOpen(true)}
          className={`group w-16 h-16 md:w-20 md:h-20 rounded-[2.2rem] md:rounded-[2.8rem] flex items-center justify-center shadow-[0_25px_50px_rgba(20,184,166,0.3)] transition-all duration-500 hover:scale-110 active:scale-90 animate-glow-pulse bg-teal-500 text-white`}
          aria-label="Open clinical chat"
        >
          <Icons.MessageSquare size={32} className="group-hover:rotate-12 transition-transform duration-500" />
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-white dark:bg-slate-900 rounded-full flex items-center justify-center shadow-lg border-2 border-teal-500">
             <div className="w-2 h-2 bg-teal-500 rounded-full animate-ping"></div>
          </div>
        </button>
      )}
    </div>
  );
};
