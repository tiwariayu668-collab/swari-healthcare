
import React from 'react';

export const AnalysisSkeleton: React.FC = () => {
  return (
    <div className="space-y-16 max-w-7xl mx-auto p-6 md:p-12 animate-entrance">
      {/* Header Skeleton */}
      <div className="space-y-6">
        <div className="h-10 shimmer rounded-full w-48 opacity-60"></div>
        <div className="h-24 md:h-32 shimmer rounded-[2rem] w-3/4"></div>
        <div className="h-8 shimmer rounded-full w-full max-w-2xl opacity-40"></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 md:gap-24">
        {/* Main Content Area */}
        <div className="lg:col-span-8 space-y-16">
          <div className="space-y-8">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 rounded-[1.8rem] shimmer"></div>
              <div className="h-12 shimmer rounded-2xl w-64"></div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              <div className="h-96 shimmer rounded-[4rem]"></div>
              <div className="h-96 shimmer rounded-[4rem]"></div>
            </div>
          </div>
          <div className="space-y-8">
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 rounded-[1.8rem] shimmer"></div>
              <div className="h-12 shimmer rounded-2xl w-48"></div>
            </div>
            <div className="h-72 shimmer rounded-[4rem]"></div>
          </div>
        </div>

        {/* Sidebar Skeleton */}
        <div className="lg:col-span-4 space-y-10">
          <div className="h-8 shimmer rounded-full w-32 ml-6"></div>
          <div className="space-y-10">
            <div className="h-64 shimmer rounded-[4rem]"></div>
            <div className="h-64 shimmer rounded-[4rem]"></div>
            <div className="h-64 shimmer rounded-[4rem]"></div>
          </div>
        </div>
      </div>
    </div>
  );
};
