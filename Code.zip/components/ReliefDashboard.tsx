
import React from 'react';
import { AnalysisResult, Product } from '../types';
import { Icons } from './Icons';
import { MOCK_PRODUCTS } from '../constants';

interface ReliefDashboardProps {
  analysis: AnalysisResult;
  onReset: () => void;
  onNavigateToContact: () => void;
  nightMode: boolean;
}

export const ReliefDashboard: React.FC<ReliefDashboardProps> = ({ analysis, onReset, onNavigateToContact, nightMode }) => {
  const getUrgencyStyles = () => {
    switch (analysis.urgency) {
      case 'High':
        return {
          text: 'text-rose-500',
          bg: 'bg-rose-500/10',
          border: 'border-rose-500/20',
          dot: 'bg-rose-500',
          gradient: 'from-rose-500/5 to-transparent',
          pulse: 'animate-pulse-rose'
        };
      case 'Medium':
        return {
          text: 'text-amber-500',
          bg: 'bg-amber-500/10',
          border: 'border-amber-500/20',
          dot: 'bg-amber-500',
          gradient: 'from-amber-500/5 to-transparent',
          pulse: 'animate-pulse-amber'
        };
      default:
        return {
          text: 'text-teal-500',
          bg: 'bg-teal-500/10',
          border: 'border-teal-500/20',
          dot: 'bg-teal-500',
          gradient: 'from-teal-500/5 to-transparent',
          pulse: 'animate-pulse-teal'
        };
    }
  };

  const urgency = getUrgencyStyles();

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-20">
      <header className="mb-12 md:mb-24 flex flex-col md:flex-row md:items-end justify-between gap-10 scroll-reveal">
        <div className="space-y-8 flex-1">
          <div className={`inline-flex items-center gap-3 px-6 py-2.5 rounded-full border ${urgency.bg} ${urgency.border} ${urgency.pulse} transition-all duration-700 backdrop-blur-md`}>
            <div className="relative flex h-2 w-2">
              <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${urgency.dot} animate-ping`}></span>
              <span className={`relative inline-flex rounded-full h-2 w-2 ${urgency.dot}`}></span>
            </div>
            <span className={`text-[10px] font-black uppercase tracking-[0.4em] ${urgency.text}`}>
              Assessment: {analysis.urgency} Priority
            </span>
          </div>
          <h1 className={`text-6xl md:text-8xl lg:text-9xl font-serif leading-[0.85] tracking-tight parallax-slide-right ${nightMode ? 'text-white' : 'text-slate-800'}`}>
            Recovery <span className="clip-text italic">Blueprint.</span>
          </h1>
          <p className={`text-xl md:text-2xl max-w-4xl leading-relaxed font-medium ${nightMode ? 'text-slate-400' : 'text-slate-500'}`}>
            {analysis.summary}
          </p>
        </div>
        <button 
          onClick={onReset}
          className={`flex items-center gap-4 px-10 py-6 rounded-[2rem] font-black text-[11px] uppercase tracking-[0.3em] transition-all liquid-button shadow-3xl ${
            nightMode ? 'bg-slate-800 text-teal-400 border border-slate-700' : 'bg-white text-slate-800 border border-slate-100 hover:border-teal-500'
          }`}
        >
          <Icons.Search size={16} /> New Narrative
        </button>
      </header>

      {/* Urgent Care Banner */}
      {analysis.urgency === 'High' && (
        <div className={`mb-16 md:mb-24 p-10 md:p-20 rounded-[4rem] md:rounded-[6rem] border-2 scroll-reveal ${
          nightMode ? 'bg-rose-950/20 border-rose-500/30' : 'bg-rose-50 border-rose-200 shadow-3xl'
        }`}>
          <div className="flex flex-col md:flex-row items-center gap-10 md:gap-20">
            <div className="w-20 h-20 md:w-32 md:h-32 rounded-[2.5rem] md:rounded-[3.5rem] bg-rose-600 flex items-center justify-center flex-shrink-0 shadow-3xl shadow-rose-600/40">
              <Icons.AlertCircle className="text-white w-10 h-10 md:w-16 md:h-16" />
            </div>
            <div className="flex-1 text-center md:text-left space-y-6">
              <h2 className={`text-4xl md:text-5xl font-serif ${nightMode ? 'text-rose-400' : 'text-rose-600'}`}>Consultation Required</h2>
              <p className={`text-lg md:text-2xl font-medium leading-relaxed opacity-80 ${nightMode ? 'text-rose-300' : 'text-rose-700'}`}>
                These markers suggest an immediate professional clinical review is the safest path forward.
              </p>
            </div>
            <button 
              onClick={onNavigateToContact}
              className="w-full md:w-auto px-12 py-6 rounded-[2rem] font-black text-[12px] uppercase tracking-[0.4em] transition-all shadow-3xl bg-rose-600 text-white hover:bg-rose-700 hover:scale-105 active:scale-95 animate-glow-pulse"
            >
              Emergency Dispatch
            </button>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 md:gap-24">
        <div className="lg:col-span-8 space-y-20 md:space-y-32">
          {/* Medications Section */}
          <section className="space-y-12">
            <div className="flex items-center gap-6 scroll-reveal">
              <div className="w-16 h-16 rounded-[1.8rem] bg-teal-500 flex items-center justify-center shadow-3xl shadow-teal-500/30">
                <Icons.Thermometer className="text-white w-8 h-8" />
              </div>
              <h2 className={`text-4xl md:text-6xl font-serif ${nightMode ? 'text-white' : 'text-slate-800'}`}>Clinical Pharmacy</h2>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
              {analysis.medications.map((med, idx) => (
                <div key={idx} className={`group p-10 md:p-14 rounded-[4rem] md:rounded-[5rem] border transition-all duration-1000 hover:-translate-y-4 hover:shadow-3xl scroll-reveal stagger-${idx + 1} ${
                  nightMode ? 'bg-slate-800/40 border-slate-700' : 'bg-white border-slate-100 shadow-sm'
                }`}>
                  <div className="flex justify-between items-start mb-10">
                    <span className="text-[10px] font-black uppercase tracking-widest text-teal-600 px-5 py-2.5 bg-teal-500/10 rounded-full border border-teal-500/20">{med.type}</span>
                  </div>
                  <h3 className={`text-3xl md:text-4xl font-black mb-8 group-hover:text-teal-500 transition-colors duration-500 ${nightMode ? 'text-white' : 'text-slate-800'}`}>{med.name}</h3>
                  <div className="space-y-8">
                    <div className="flex items-start gap-4">
                      <Icons.Activity className="text-teal-500 mt-1 w-6 h-6" />
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400 mb-2">Protocol</p>
                        <p className={`text-xl font-medium leading-relaxed ${nightMode ? 'text-slate-300' : 'text-slate-600'}`}>{med.dosage}</p>
                      </div>
                    </div>
                    <div className={`p-8 rounded-[3rem] border transition-all duration-500 group-hover:scale-[1.02] ${
                      nightMode ? 'bg-amber-950/10 border-amber-500/20 text-amber-400' : 'bg-amber-50 border-amber-100 text-amber-600 shadow-xl shadow-amber-500/5'
                    }`}>
                      <p className="text-[10px] font-black uppercase tracking-[0.3em] mb-3 opacity-70">Mandatory Caution</p>
                      <p className="text-lg font-bold leading-relaxed">{med.precautions}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Lifestyle Section */}
          <section className="space-y-12">
            <div className="flex items-center gap-6 scroll-reveal">
              <div className="w-16 h-16 rounded-[1.8rem] bg-amber-100 flex items-center justify-center">
                <Icons.Droplets className="text-amber-500 w-8 h-8" />
              </div>
              <h2 className={`text-4xl md:text-6xl font-serif ${nightMode ? 'text-white' : 'text-slate-800'}`}>Holistic Care</h2>
            </div>
            
            <div className={`p-10 md:p-20 rounded-[4rem] md:rounded-[6rem] border transition-all duration-1000 scroll-reveal ${
              nightMode ? 'bg-slate-800/20 border-slate-700' : 'bg-white border-slate-50 shadow-3xl shadow-teal-500/5'
            }`}>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12 md:gap-20">
                {analysis.remedies.map((rem, idx) => (
                  <div key={idx} className="space-y-6 group scroll-reveal stagger-1">
                    <span className="text-[10px] font-black uppercase tracking-[0.4em] text-teal-500 block">{rem.category} Essence</span>
                    <h4 className={`text-2xl md:text-3xl font-black group-hover:text-teal-500 transition-colors duration-500 ${nightMode ? 'text-white' : 'text-slate-800'}`}>{rem.title}</h4>
                    <p className={`text-lg md:text-2xl leading-relaxed opacity-60 font-medium ${nightMode ? 'text-slate-400' : 'text-slate-500'}`}>{rem.description}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>
        </div>

        {/* Sidebar Shop */}
        <aside className="lg:col-span-4 space-y-12 pb-20 lg:pb-0">
          <div className="lg:sticky lg:top-40 space-y-12 scroll-reveal">
            <div className="flex items-center justify-between px-6">
              <h3 className={`text-3xl font-black ${nightMode ? 'text-white' : 'text-slate-800'}`}>Sanctuary Kit</h3>
              <Icons.ShoppingBag className="text-teal-500 w-6 h-6" />
            </div>
            <div className="space-y-10">
              {MOCK_PRODUCTS.slice(0, 3).map((product, idx) => (
                <div key={product.id} className={`scroll-reveal stagger-${idx + 1}`}>
                  <CompactProductCard product={product} nightMode={nightMode} />
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};

const CompactProductCard: React.FC<{ product: Product, nightMode: boolean }> = ({ product, nightMode }) => {
  return (
    <div className="group relative">
      <div className={`p-8 md:p-10 rounded-[4rem] md:rounded-[5rem] border transition-all duration-1000 hover:-translate-y-4 hover:shadow-3xl ${
        nightMode ? 'bg-slate-800 border-slate-700' : 'bg-white border-slate-50 shadow-sm'
      }`}>
        <div className="aspect-square rounded-[3rem] md:rounded-[3.5rem] overflow-hidden bg-slate-50 mb-8 border border-slate-100/50 dark:border-slate-700 relative reveal-mask">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover transition-transform duration-[2s] group-hover:scale-110" />
          <div className="absolute top-6 left-6 z-10 bg-white/95 backdrop-blur-3xl px-4 py-2 rounded-full text-[9px] font-black uppercase tracking-widest text-teal-600 shadow-2xl">Verified</div>
        </div>
        <div className="space-y-6">
          <div className="flex justify-between items-start">
            <div className="flex-1 pr-4">
              <h4 className={`text-2xl font-black leading-tight group-hover:text-teal-500 transition-colors duration-500 ${nightMode ? 'text-white' : 'text-slate-800'}`}>{product.name}</h4>
              <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.3em] mt-3">{product.brand}</p>
            </div>
            <p className="text-2xl font-black text-teal-600">₹{product.price.toFixed(0)}</p>
          </div>
          <div className="flex items-center gap-2">
            <Icons.Star className="fill-yellow-400 text-yellow-400 w-4 h-4" />
            <span className={`text-[12px] font-black ${nightMode ? 'text-slate-300' : 'text-slate-800'}`}>{product.rating}</span>
            <span className="text-[10px] text-slate-400 font-bold ml-auto uppercase tracking-tighter">{product.reviewCount} Care Reviews</span>
          </div>
          <button className="w-full py-6 rounded-[2.5rem] bg-teal-600 text-white font-black text-[12px] uppercase tracking-[0.4em] transition-all liquid-button shadow-3xl active:scale-95 animate-glow-pulse">
            Secure Buy
          </button>
        </div>
      </div>
    </div>
  );
};
