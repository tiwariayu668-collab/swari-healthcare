import React, { useState, useMemo } from 'react';
import { BODY_MAP_REGIONS_FRONT, BODY_MAP_REGIONS_BACK } from '../constants';
import { BodyRegion, ViewMode, Gender } from '../types';
import { Icons } from './Icons';

interface BodyMapProps {
  onSelectRegion: (region: BodyRegion) => void;
  selectedRegion: BodyRegion | null;
  nightMode: boolean;
}

export const BodyMap: React.FC<BodyMapProps> = ({ onSelectRegion, selectedRegion, nightMode }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('front');
  const [gender, setGender] = useState<Gender>('male');
  const [hoveredRegion, setHoveredRegion] = useState<BodyRegion | null>(null);

  const regions = useMemo(() => (viewMode === 'front' ? BODY_MAP_REGIONS_FRONT : BODY_MAP_REGIONS_BACK), [viewMode]);
  
  const activeRegionData = useMemo(() => {
    return regions.find(r => r.id === selectedRegion);
  }, [regions, selectedRegion]);

  // Medically-inspired silhouettes with 3D contours
  const maleSilhouette = "M50,12 c-7,0 -12,5 -12,14 c0,9 5,16 12,16 s12,-7 12,-16 c0,-9 -5,-14 -12,-14 M42,46 l16,0 l2,7 l-20,0 z M25,60 c5,-2 45,-2 50,0 c12,4 16,24 16,34 c0,15 -18,105 -22,150 l-15,0 l2,-80 l-4,0 l2,80 l-15,0 c-4,-45 -22,-135 -22,-150 c0,-10 4,-30 14,-34 z";
  const femaleSilhouette = "M50,14 c-6,0 -11,5 -11,13 c0,9 5,15 11,15 s11,-7 11,-15 c0,-8 -5,-13 -11,-13 M43,46 l14,0 l2,7 l-18,0 z M30,60 c6,-3 34,-3 40,0 c14,5 18,28 18,38 c0,15 -22,110 -24,150 l-12,0 l1,-75 l-4,0 l1,75 l-12,0 c-2,-40 -24,-135 -24,-150 c0,-10 6,-32 14,-37 z";

  const handleInteraction = (regionId: BodyRegion) => {
    onSelectRegion(regionId);
  };

  return (
    <div className={`relative w-full max-w-[360px] md:max-w-[500px] mx-auto flex flex-col items-center justify-between p-6 md:p-12 rounded-[4rem] md:rounded-[6rem] shadow-4xl border transition-all duration-1000 animate-entrance group/container ${
      nightMode ? 'bg-slate-900/40 border-slate-700/30' : 'bg-white/40 border-teal-50/50 backdrop-blur-3xl'
    }`} style={{ touchAction: 'none' }}>
      
      {/* Dynamic Background Glow */}
      <div className="absolute inset-0 bg-gradient-to-tr from-teal-500/5 via-transparent to-amber-500/5 rounded-[6rem] pointer-events-none"></div>
      
      {/* Controls */}
      <div className="w-full flex justify-between items-center mb-10 z-[60]">
        <div className="flex bg-slate-200/50 dark:bg-slate-800/50 p-1.5 rounded-2xl border border-white/20 backdrop-blur-3xl shadow-lg">
          <button 
            onClick={() => setGender('male')}
            className={`px-5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
              gender === 'male' ? 'bg-white dark:bg-slate-600 text-teal-600 shadow-2xl scale-105' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            Male
          </button>
          <button 
            onClick={() => setGender('female')}
            className={`px-5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${
              gender === 'female' ? 'bg-white dark:bg-slate-600 text-teal-600 shadow-2xl scale-105' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            Female
          </button>
        </div>
        <button 
          onClick={() => setViewMode(viewMode === 'front' ? 'back' : 'front')}
          className="p-4 bg-white/95 dark:bg-slate-800/95 rounded-[1.6rem] shadow-3xl border border-teal-100/30 active:scale-90 transition-all group flex items-center gap-3"
        >
          <Icons.Activity size={18} className={`text-teal-500 transition-transform duration-1000 ${viewMode === 'back' ? 'rotate-180' : ''}`} />
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest hidden sm:inline">{viewMode} View</span>
        </button>
      </div>

      <div className="flex-1 w-full relative flex items-center justify-center overflow-hidden rounded-[4rem] min-h-[440px]">
        {/* MRI Scanline Effect - Ensure pointer-events-none so it doesn't block touch */}
        <div className="absolute inset-x-0 h-1 bg-gradient-to-r from-transparent via-teal-400/80 to-transparent z-10 pointer-events-none" 
             style={{ animation: 'scanline 5s linear infinite', filter: 'blur(2px)' }}></div>
        <div className="absolute inset-x-0 h-24 bg-gradient-to-b from-teal-400/10 to-transparent z-10 pointer-events-none"
             style={{ animation: 'scanline 5s linear infinite' }}></div>

        {/* The 3D Body SVG - Explicit z-index to stay above scanlines but below overlay */}
        <svg 
          viewBox="0 0 100 260" 
          className="w-full h-full relative z-20 transition-all duration-1000 drop-shadow-[0_30px_60px_rgba(0,0,0,0.2)] cursor-crosshair"
          onClick={() => selectedRegion && onSelectRegion(null as any)}
        >
          <defs>
            <linearGradient id="bodyBaseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" style={{ stopColor: nightMode ? '#1e293b' : '#ffffff', stopOpacity: 1 }} />
              <stop offset="100%" style={{ stopColor: nightMode ? '#0f172a' : '#f8fafc', stopOpacity: 1 }} />
            </linearGradient>

            <filter id="glassMri" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur in="SourceAlpha" stdDeviation="1.5" result="blur" />
              <feOffset dx="1" dy="2" result="offsetBlur" />
              <feSpecularLighting in="blur" surfaceScale="5" specularConstant=".75" specularExponent="20" lightingColor="#ffffff" result="specOut">
                <fePointLight x="-5000" y="-10000" z="20000" />
              </feSpecularLighting>
              <feComposite in="specOut" in2="SourceAlpha" operator="in" result="specOut" />
              <feComposite in="SourceGraphic" in2="specOut" operator="arithmetic" k1="0" k2="1" k3="1" k4="0" result="litGraphic" />
            </filter>

            <pattern id="bodyMesh" width="8" height="8" patternUnits="userSpaceOnUse">
              <path d="M 8 0 L 0 0 0 8" fill="none" stroke={nightMode ? "rgba(255,255,255,0.03)" : "rgba(0,0,0,0.04)"} strokeWidth="0.5"/>
            </pattern>
          </defs>

          {/* Background Grid Mesh - Handles deselect clicks */}
          <rect 
            width="100%" 
            height="100%" 
            fill="url(#bodyMesh)" 
            className="pointer-events-auto"
            onClick={(e) => { e.stopPropagation(); onSelectRegion(null as any); }}
          />
          
          {/* Main Body Silhouette */}
          <path 
            d={gender === 'male' ? maleSilhouette : femaleSilhouette} 
            fill="url(#bodyBaseGradient)"
            filter="url(#glassMri)"
            stroke={nightMode ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.05)"}
            strokeWidth="0.5"
            className="transition-all duration-1000"
            pointerEvents="none"
          />

          {/* Internal Anatomical Hints */}
          <g opacity="0.15" stroke={nightMode ? "#ffffff" : "#000000"} fill="none" strokeWidth="0.4" pointerEvents="none">
             <path d="M40,75 C45,72 55,72 60,75 M38,85 C42,82 58,82 62,85 M37,95 C43,92 57,92 63,95" />
             <path d="M50,65 L50,150" strokeDasharray="2,2" />
             <path d="M35,148 C42,152 58,152 65,148" />
          </g>

          {/* Interactive Segments - explicitly above silhouette */}
          {regions.map((reg) => (
            <path
              key={reg.id}
              d={reg.path}
              onMouseEnter={() => setHoveredRegion(reg.id as BodyRegion)}
              onMouseLeave={() => setHoveredRegion(null)}
              onClick={(e) => { e.stopPropagation(); handleInteraction(reg.id as BodyRegion); }}
              onPointerDown={(e) => { e.stopPropagation(); handleInteraction(reg.id as BodyRegion); }}
              className={`cursor-pointer transition-all duration-300 ease-out pointer-events-auto ${
                selectedRegion === reg.id 
                  ? 'fill-teal-500/40 stroke-teal-500 stroke-[2] drop-shadow-[0_0_15px_rgba(20,184,166,0.8)] scale-[1.01]' 
                  : hoveredRegion === reg.id 
                    ? 'fill-teal-500/20 stroke-teal-500/50' 
                    : 'fill-transparent stroke-transparent'
              }`}
              style={{ transformOrigin: 'center' }}
            />
          ))}

          {/* Active Pulse Marker */}
          {selectedRegion && (
            <circle 
              cx="50" 
              cy={selectedRegion === BodyRegion.HEAD ? 26 : selectedRegion === BodyRegion.NECK ? 48 : 100}
              r="8"
              fill="#14b8a6"
              className="animate-ping pointer-events-none opacity-60"
            />
          )}
        </svg>

        {/* CONDITION INSIGHT OVERLAY - Every disease for that part */}
        {activeRegionData && (
          <div className="absolute inset-0 z-[100] flex items-center justify-center pointer-events-none p-4">
             <div className="bg-white/98 dark:bg-slate-900/98 backdrop-blur-3xl rounded-[3rem] p-8 border border-teal-500/40 shadow-[0_40px_100px_rgba(0,0,0,0.4)] pointer-events-auto animate-entrance max-w-[300px] w-full transform -translate-y-4">
                <div className="flex items-center justify-between mb-6">
                   <div className="flex items-center gap-3">
                      <div className="p-2.5 bg-teal-500/10 rounded-xl">
                        <Icons.ShieldCheck className="text-teal-500" size={18} />
                      </div>
                      <h3 className={`font-black uppercase tracking-[0.2em] text-[11px] ${nightMode ? 'text-white' : 'text-slate-800'}`}>
                        {selectedRegion} Conditions
                      </h3>
                   </div>
                   <button 
                      onClick={(e) => { e.stopPropagation(); onSelectRegion(null as any); }}
                      className="p-2 -mr-2 text-slate-400 hover:text-teal-500 transition-colors"
                   >
                     <Icons.X size={20} />
                   </button>
                </div>

                <div className="space-y-4 max-h-[250px] overflow-y-auto pr-2 scrollbar-hide">
                   {activeRegionData.conditions?.map((cond, i) => (
                      <div key={i} className={`p-4 rounded-2xl border transition-all hover:scale-[1.02] ${
                        nightMode ? 'bg-slate-800/80 border-slate-700' : 'bg-slate-50 border-slate-100 shadow-sm'
                      }`}>
                         <div className="flex justify-between items-center mb-1">
                            <span className={`font-black text-[12px] ${nightMode ? 'text-teal-400' : 'text-teal-600'}`}>
                               {cond.name}
                            </span>
                            <span className={`text-[8px] font-black uppercase tracking-tighter px-2 py-0.5 rounded-full ${
                               cond.risk === 'High' ? 'bg-rose-500/20 text-rose-500' :
                               cond.risk === 'Moderate' ? 'bg-amber-500/20 text-amber-500' :
                               'bg-teal-500/20 text-teal-500'
                            }`}>
                               {cond.risk} Risk
                            </span>
                         </div>
                         <p className={`text-[10px] leading-relaxed opacity-70 font-medium ${nightMode ? 'text-slate-300' : 'text-slate-500'}`}>
                            {cond.symptoms}
                         </p>
                      </div>
                   ))}
                </div>

                <button 
                  className="w-full mt-6 py-4 bg-teal-600 hover:bg-teal-700 text-white font-black text-[10px] uppercase tracking-[0.3em] rounded-2xl transition-all shadow-xl active:scale-95 animate-glow-pulse"
                  onClick={() => onSelectRegion(selectedRegion as BodyRegion)}
                >
                  Analyze Symptoms
                </button>
             </div>
          </div>
        )}

        {/* Static Badge */}
        {!selectedRegion && (
           <div className="absolute bottom-10 left-1/2 -translate-x-1/2 pointer-events-none transition-all duration-700 opacity-80">
             <div className="bg-white/90 dark:bg-slate-900/90 backdrop-blur-3xl px-6 py-3 rounded-full border border-teal-500/20 shadow-2xl flex items-center gap-3">
                <Icons.Activity className="text-teal-500 animate-pulse" size={14} />
                <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-500 dark:text-slate-400">Touch a region for insights</span>
             </div>
           </div>
        )}
      </div>

      {/* Footer Indicators */}
      <div className="mt-10 grid grid-cols-2 gap-4 w-full z-20">
         <div className="bg-white/60 dark:bg-slate-800/60 p-4 rounded-[1.5rem] border border-white/20 text-center backdrop-blur-3xl shadow-sm hover:shadow-md transition-shadow">
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Topology</p>
            <p className="text-[11px] font-black text-teal-600 dark:text-teal-400">High-Fidelity</p>
         </div>
         <div className="bg-white/60 dark:bg-slate-800/60 p-4 rounded-[1.5rem] border border-white/20 text-center backdrop-blur-3xl shadow-sm hover:shadow-md transition-shadow">
            <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest mb-1">Feedback</p>
            <p className="text-[11px] font-black text-teal-600 dark:text-teal-400">Haptic Touch</p>
         </div>
      </div>
    </div>
  );
};
